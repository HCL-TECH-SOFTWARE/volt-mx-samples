define(function () {
  return {
    setupPushCallbacks: function(){
      voltmx.print("in setupPushCallbacks()");
      var pushMod = require('./pushNotif');
      var callbacksTable = {};
      callbacksTable = {  onsuccessfulregistration: pushMod.regSuccessCallback,
                        onfailureregistration: pushMod.regFailureCallback,
                        onlinenotification: pushMod.onlinePushNotificationCallback,
                        offlinenotification: pushMod.offlinePushNotificationCallback,
                        onsuccessfulderegistration: pushMod.unregSuccessCallback, 
                        onfailurederegistration:pushMod.unregFailureCallback
                       };

      voltmx.push.setCallbacks(callbacksTable);
    },
    registerPushNotification: function(){
      var senderID="";
      senderID =this.view.txtBoxSenderID.text;
      this.SenderId = senderID;
      var devName = voltmx.os.deviceInfo().name;
      if (devName === "android") {
        var configToRegister = {senderid:senderID};
        voltmx.push.register(configToRegister);
      }else{
        var notificationTypes = [0, 1, 2];
        voltmx.push.register(notificationTypes);
      }

    },

    unregisterPushNotification: function(){
      voltmx.push.deRegister({});
    },
    regSuccessCallback: function(regId) {
      voltmx.print("\n\n\n<--------in regSuccessAndroidCallback--------->\n\n\n");
      voltmx.print("\nRegistration Id-->"+JSON.stringify(regId));
      voltmx.store.setItem("isFirstTime","true");
    },

    regFailureCallback: function(errObj) {
      voltmx.print("************ JS regFailureCallback() called *********" + JSON.stringify(errObj));
      alert("Registration Failed: " + JSON.stringify(errObj));
    },

    unregSuccessCallback : function()
    {
      var pushMod = require('./pushNotif');
      pushMod.unsubscribeFoundryPush();

    },

    unregFailureCallback : function(errormsg)
    {
      alert(" Unregistration Failed");
    },

    unsubscribeFoundryPush: function() {
      try{
        var messagingSvc = voltmx.sdk.getDefaultInstance().getMessagingService();
        var options = {
          "authToken": ""
        };
        messagingSvc.unregister(function(response) {
          voltmx.print("Foundry Unsubscribe Succesful.");
          var msg = "Device unregistered successfully. To continue using this app, you need to create a new subscription";
          alert(msg);
        }, function(error) {
          alert("Foundry Unsubscribe Failure.");
        }, options);
      }catch(e){
        voltmx.print("Error in unsubscribeFoundryPush.");
      }
    },
    onlinePushNotificationCallback: function(msg) {
      kony.print("************ JS onlinePushNotificationCallback() called *********");
      kony.print(JSON.stringify(msg));
      //alert("Online Push "+JSON.stringify(msg));
      var currentForm = kony.application.getCurrentForm();
      if(currentForm === null || currentForm === undefined || currentForm === ""){
        alert("Error occured while getting the Online Push Try Again.");
      }else{
        var pushMod = require('./pushNotif');
        pushMod.insertPopUp(currentForm);
        if(msg["isRichPush"]!==undefined){
          var serviceName = "msgHistory";
          var integrationObj = KNYMobileFabric.getIntegrationService(serviceName);
          var operationName =  "getRichPushMessageContent";
          var data= {
            "pushId" : msg["mid"]
          };
          var headers= {};
          integrationObj.invokeOperation(operationName, headers, data, pushMod.operationSuccessRichPush, pushMod.operationFailureRichPush);
        }else{
          try {
            if (voltmx.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY))
            {
              var serviceName1 = "msgHistory";
              var integrationObj1 = KNYMobileFabric.getIntegrationService(serviceName1);
              var operationName1 =  "getPushMessageFullContent";
              var data1= {"pushId": msg["mid"]};
              var headers1= {};
              integrationObj1.invokeOperation(operationName1, headers1, data1,pushMod.getNormalContentSuccessCallback, pushMod.getNormalContentFailure);
            }
            else
              alert("Network unavailable");
          } catch (err) {
            kony.print("\nexception in invoking service---\n" + JSON.stringify(err));
            alert("Error" + err);
          }
        }
      }

    },

    insertPopUp : function(currentForm){
      if(typeof currentForm.pushAlert === "undefined" || currentForm.pushAlert === null ){
        var customAlert = new com.voltmx.customAlert(
          {
            "clipBounds": true,
            "height": "100%",
            "id": "pushAlert",
            "isVisible": true,
            "left": "0dp",
            "top": "0dp",
            "width": "100%",
            "zIndex": 90
          }, {}, {});
        currentForm.add(customAlert);
      }
    },
    getNormalContentSuccessCallback : function(response){
      var currentForm = voltmx.application.getCurrentForm();
      if(currentForm === null || currentForm === undefined || currentForm === ""){
        alert("Error Occured while getting Online Push.Try Again");
      }else{
        currentForm.pushAlert.openPopUp(false,"",response.content);
      }
    },
    getNormalContentFailure : function(error){
      voltmx.model.ApplicationContext.dismissLoadingScreen();
      alert("Failed to get the Push.");
    },
    operationSuccessRichPush : function(response){
      var currentForm = voltmx.application.getCurrentForm();
      if(currentForm === null || currentForm === undefined || currentForm === ""){
        alert("Error Occured while getting Online Push.Try Again");
      }else{
        currentForm.pushAlert.openPopUp(true,"",response.rawResponse);
        var pushMod = require('./pushNotif');
      }
    },
    operationFailureRichPush : function(error){
      voltmx.model.ApplicationContext.dismissLoadingScreen();
      alert("Failed to get the Push.");
    },
    offlinePushNotificationCallback: function(msg) {
      voltmx.print("************ JS offlinePushNotificationCallback() called *********");
      voltmx.print(msg);
      var devName = voltmx.os.deviceInfo().name;
      if (devName === "android") {
        if(msg["content-available"]!=1){
          alert("Message: "+msg["content"]);
        }
        else{
          alert("silent push received");
        }
      }else{
        alert("Message: "+JSON.stringify(msg.alert));
      }
    }

  };
});