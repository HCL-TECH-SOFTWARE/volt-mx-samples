function AS_FlexContainer_g6daf4c84e5944cd8c4d05dc91133c3d(eventobject) {
    var self = this;
    this.loginCheck(1);
}