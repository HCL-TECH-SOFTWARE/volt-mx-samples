function AS_Button_d8f93166d7a44ffb85f7bf050faf2384(eventobject) {
    var self = this;
    this.pushRegistration()
}