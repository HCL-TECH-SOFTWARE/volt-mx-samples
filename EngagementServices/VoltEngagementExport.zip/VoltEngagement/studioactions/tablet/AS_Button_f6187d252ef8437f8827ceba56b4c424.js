function AS_Button_f6187d252ef8437f8827ceba56b4c424(eventobject) {
    var self = this;
    var navigateToDetailsForm = new kony.mvc.Navigation("frmHome");
    navigateToDetailsForm.navigate();
}