define({
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_AppEvents_e1cb5562819444eab57cf44be1fb0a1b: function AS_AppEvents_e1cb5562819444eab57cf44be1fb0a1b(eventobject) {
        var self = this;
        var pushMod = require('./pushNotif');
        //setupPushCallbacks
        pushMod.setupPushCallbacks();
    }
});