function AS_AppEvents_e1cb5562819444eab57cf44be1fb0a1b(eventobject) {
    var self = this;
    var pushMod = require('./pushNotif');
    //setupPushCallbacks
    pushMod.setupPushCallbacks();
}