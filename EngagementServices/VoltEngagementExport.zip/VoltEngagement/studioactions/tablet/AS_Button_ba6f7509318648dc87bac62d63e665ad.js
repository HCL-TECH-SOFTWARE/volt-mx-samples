function AS_Button_ba6f7509318648dc87bac62d63e665ad(eventobject) {
    var self = this;
    this.pushRegistration();
}