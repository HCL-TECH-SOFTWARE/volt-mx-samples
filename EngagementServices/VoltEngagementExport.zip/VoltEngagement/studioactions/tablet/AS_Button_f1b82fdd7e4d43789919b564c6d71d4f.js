function AS_Button_f1b82fdd7e4d43789919b564c6d71d4f(eventobject) {
    var self = this;
    this.autenticateUser();
}