function AS_TextField_a7e6ff6dab634ceeaa8df84705caebc6(eventobject, changedtext) {
    var self = this;
    this.checkBoxSelection("email");
}