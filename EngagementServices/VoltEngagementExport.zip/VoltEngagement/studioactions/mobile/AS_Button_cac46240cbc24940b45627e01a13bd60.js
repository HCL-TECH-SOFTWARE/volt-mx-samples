function AS_Button_cac46240cbc24940b45627e01a13bd60(eventobject) {
    var self = this;
    var navigateToDetailsForm = new kony.mvc.Navigation("frmHome");
    navigateToDetailsForm.navigate();
}