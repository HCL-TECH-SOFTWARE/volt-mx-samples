define({
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_AppEvents_j7c791d2c02a470d9624c8933043a98b: function AS_AppEvents_j7c791d2c02a470d9624c8933043a98b(eventobject) {
        var self = this;
        var pushMod = require('./pushNotif');
        //setupPushCallbacks
        pushMod.setupPushCallbacks();
    }
});