function AS_Button_c0a75d387f964a0ebb22c8eb69f187d2(eventobject) {
    var self = this;
    this.pushRegistration()
}