function AS_Button_dbc9c1f6cdeb4be38dc8973822d828de(eventobject) {
    var self = this;
    this.pushRegistration()
}