function AS_Button_ed1f80b5a13a404a9a3d7b4bc083ae98(eventobject) {
    var self = this;
    this.pushRegistration()
}