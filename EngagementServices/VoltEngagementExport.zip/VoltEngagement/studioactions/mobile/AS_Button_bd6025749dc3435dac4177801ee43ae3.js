function AS_Button_bd6025749dc3435dac4177801ee43ae3(eventobject) {
    var self = this;
    this.closePopUp();
}