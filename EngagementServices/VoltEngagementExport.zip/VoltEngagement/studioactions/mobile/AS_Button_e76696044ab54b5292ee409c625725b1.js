function AS_Button_e76696044ab54b5292ee409c625725b1(eventobject) {
    var self = this;
    this.autenticateUser();
}