function AS_AppEvents_j7c791d2c02a470d9624c8933043a98b(eventobject) {
    var self = this;
    var pushMod = require('./pushNotif');
    //setupPushCallbacks
    pushMod.setupPushCallbacks();
}