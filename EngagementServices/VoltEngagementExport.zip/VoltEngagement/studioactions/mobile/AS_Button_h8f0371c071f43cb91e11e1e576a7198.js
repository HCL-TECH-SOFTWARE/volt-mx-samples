function AS_Button_h8f0371c071f43cb91e11e1e576a7198(eventobject) {
    var self = this;
    this.closePopUp();
}