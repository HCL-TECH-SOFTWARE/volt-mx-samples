function AS_ListBox_f46c62833ad54cda9cf04fd663b0d7a8(eventobject) {
    var self = this;
    selectedState = frmProfile.lstboxStates.selectedKeyValue[1];
    //alert(selectedState);
}