function AS_Button_f700550d63a845b286e9293cdabc7d74(eventobject) {
    var self = this;
    var ntf = new voltmx.mvc.Navigation("frmSubscription");
    ntf.navigate();
}