function AS_Button_e442b059f6754dd4b907ccae74fb26d7(eventobject) {
    var self = this;
    var navigateToDetailsForm = new kony.mvc.Navigation("frmHome");
    navigateToDetailsForm.navigate();
}