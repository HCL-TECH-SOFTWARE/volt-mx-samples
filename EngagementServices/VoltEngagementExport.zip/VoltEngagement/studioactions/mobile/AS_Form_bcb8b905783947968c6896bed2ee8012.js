function AS_Form_bcb8b905783947968c6896bed2ee8012(eventobject) {
var self = this;
frmGeoLocations.btnMap.text="Map";
frmGeoLocations.segLocations.isVisible=true;
frmGeoLocations.mapLocations.isVisible=false;

}