function AS_TextField_d71d3040f1bd46a696308b8fb6ff39dd(eventobject, changedtext) {
    var self = this;
    this.checkBoxSelection("email");
}