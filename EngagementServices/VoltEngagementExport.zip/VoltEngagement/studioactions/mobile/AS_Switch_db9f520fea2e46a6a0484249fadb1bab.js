function AS_Switch_db9f520fea2e46a6a0484249fadb1bab(eventobject) {
    var self = this;
    this.pushRegistration();
}