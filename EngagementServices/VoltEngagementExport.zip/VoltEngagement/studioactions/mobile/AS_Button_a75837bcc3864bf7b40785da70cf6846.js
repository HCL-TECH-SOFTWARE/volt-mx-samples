function AS_Button_a75837bcc3864bf7b40785da70cf6846(eventobject) {
    var self = this;
    var navigateToDetailsForm = new kony.mvc.Navigation("frmHome");
    navigateToDetailsForm.navigate();
}