function AS_Button_db663d7949324877bfe1f66453964a24(eventobject) {
    var self = this;
    this.triggerAdhocPush();
}