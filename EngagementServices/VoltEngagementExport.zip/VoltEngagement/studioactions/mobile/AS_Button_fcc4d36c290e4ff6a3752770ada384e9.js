function AS_Button_fcc4d36c290e4ff6a3752770ada384e9(eventobject) {
    var self = this;
    var navigateToDetailsForm = new kony.mvc.Navigation("frmHome");
    navigateToDetailsForm.navigate();
}