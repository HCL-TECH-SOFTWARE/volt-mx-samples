
var dragInteraction1;
var drpInteraction1;

function form9preshow(){
  createcallbacksdictAndAddDragInteractionImg1Form9();
  createcallbacksdictAndAddDropInteractionImg2Form9();
}

function createcallbacksdictAndAddDragInteractionImg1Form9(){
  var callbacksDict = {
        "itemsForBeggining": beginItemDragForm9,
        "previewForLifting": previewForLiftingForm9
    };
  var argsDict = {
        "widget": this.view.img1,
        "callbacks": callbacksDict
    };
   
    dragInteraction1 = new kony.dragdrop.DragInteraction(argsDict);
}

function createcallbacksdictAndAddDropInteractionImg2Form9(){
  var callbacksDict = {
        "performDrop": dropCallbackForm9
    };
  var argsDict = {
        "widget":this.view.img2,
        "callbacks": callbacksDict
    };
    drpInteraction1 = new kony.dragdrop.DropInteraction(argsDict);
}

function beginItemDragForm9(){
  var applicationDirPath = kony.io.FileSystem.getApplicationDirectoryPath();
  var filePath = applicationDirPath+"/puppy.png";
  var argsDict = {
        "data": filePath,
        "type": kony.dragdrop.ITEMDATA_FILE,
        "fileVisibility": kony.dragdrop.FILEVISIBILITY_ALL
    };
    return [argsDict];
} 

function dropCallbackForm9(recievedData){
   var file = kony.io.FileSystem.getFile(recievedData);
  if(file.exists()){
    var fileBytes = file.read();
    this.view.img2.base64 = kony.convertToBase64(fileBytes);
  }
}

function previewForLiftingForm9(){
  var argsDict = {
        "preview": this.view.img1
    };
    return argsDict;
}

// function enableDragInteraction1(){
//   dragInteraction1.enabled = true;
//  }

// function diableDragInteraction1(){
//   dragInteraction1.enabled = false;
//  }

// function removeDragInteraction1(){
//   dragInteraction1.removeDragInteraction();
// }

// function removeDropInteraction1(){
//   drpInteraction1.removeDropInteraction();
// }

