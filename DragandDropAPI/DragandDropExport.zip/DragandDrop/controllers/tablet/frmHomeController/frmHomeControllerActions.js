define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onDownloadComplete defined for img1 **/
    AS_Image_fe9cf1088ae344b7af5ccb86af50cd75: function AS_Image_fe9cf1088ae344b7af5ccb86af50cd75(eventobject, imagesrc, issuccess) {
        var self = this;
    },
    /** onClick defined for btnRemoveDrag **/
    AS_Button_b33c5c9b1b024100875de3d7fdff61cd: function AS_Button_b33c5c9b1b024100875de3d7fdff61cd(eventobject) {
        var self = this;
        return self.removeDragInteraction1.call(this);
    },
    /** onClick defined for CopybtnRemoveDrag0c5f591df4d0d45 **/
    AS_Button_c2270ffaa98d44bc9ebac94dc3ba7e51: function AS_Button_c2270ffaa98d44bc9ebac94dc3ba7e51(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("Form2");
        ntf.navigate();
    },
    /** onClick defined for btnRemoveDrop **/
    AS_Button_a4080bb504ab49bdbbcd376160b45b19: function AS_Button_a4080bb504ab49bdbbcd376160b45b19(eventobject) {
        var self = this;
        return self.removeDropInteraction1.call(this);
    },
    /** preShow defined for frmHome **/
    AS_Form_d0ad3bad10cf4a80b679f4e4f28483c2: function AS_Form_d0ad3bad10cf4a80b679f4e4f28483c2(eventobject) {
        var self = this;
        try {
            this.formpreshow();
        } catch (e) {
            alert(JSON.stringify(e));
        }
    }
});