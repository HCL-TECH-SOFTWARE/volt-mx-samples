define( {
    //Type your controller code here 
    dragInteraction1: null,
    drpInteraction1: null,
    formpreshow: function() {
        this.createcallbacksdictAndAddDragInteractionImg1();
        this.createcallbacksdictAndAddDropInteractionImg2();
    },
    createcallbacksdictAndAddDragInteractionImg1: function() {
        var callbacksDict = {
            "itemsForBeggining": this.beginItemDragForm9,
            "previewForLifting": this.previewForLiftingForm9
        };
        var argsDict = {
            "widget": this.view.img1,
            "callbacks": callbacksDict
        };
        this.dragInteraction1 = new kony.dragdrop.DragInteraction(argsDict);
   
    },
    createcallbacksdictAndAddDropInteractionImg2: function() {
        var callbacksDict = {
            "performDrop": this.dropCallbackForm9
        };
        var argsDict = {
            "widget": this.view.img2,
            "callbacks": callbacksDict
        };
        this.drpInteraction1 = new kony.dragdrop.DropInteraction(argsDict);
    },
    beginItemDragForm9: function() {
        var applicationDirPath = kony.io.FileSystem.getApplicationDirectoryPath();
        var filePath = applicationDirPath + "/puppy.png";
        var argsDict = {
            "data": filePath,
            "type": kony.dragdrop.ITEMDATA_FILE,
            "fileVisibility": kony.dragdrop.FILEVISIBILITY_ALL
        };
        return [argsDict];
    },
    dropCallbackForm9: function(recievedData) {
        var file = kony.io.FileSystem.getFile(recievedData);
        if (file.exists()) {
            var fileBytes = file.read();
            this.view.img2.base64 = kony.convertToBase64(fileBytes);
        }
    },
    previewForLiftingForm9: function() {
        var argsDict = {
            "preview": this.view.img1
        };
        return argsDict;
    },
    removeDragInteraction1: function() {
        this.dragInteraction1.removeDragInteraction();
      
    },
    removeDropInteraction1: function() {
        this.drpInteraction1.removeDropInteraction();
    }
});
// define("Form9ControllerActions", {
//     /*
//       This is an auto generated file and any modifications to it may result in corruption of the action sequence.
//     */
//     /** onDownloadComplete defined for img1 **/
//     AS_Image_fe9cf1088ae344b7af5ccb86af50cd75: function AS_Image_fe9cf1088ae344b7af5ccb86af50cd75(eventobject, imagesrc, issuccess) {
//         var self = this;
//     },
//     /** onClick defined for Button0j668681d39654b **/
//     AS_Button_e99aac1ddd794ba5a027b6e0af217cee: function AS_Button_e99aac1ddd794ba5a027b6e0af217cee(eventobject) {
//         var self = this;
//         return self.enableDragInteraction1.call(this);
//     },
//     /** onClick defined for Button0bdc625c015f949 **/
//     AS_Button_e63e67282c5d43c39727b89fc84f5763: function AS_Button_e63e67282c5d43c39727b89fc84f5763(eventobject) {
//         var self = this;
//         return self.disableDragInteraction1.call(this);
//     },
//     /** onClick defined for Button0e588e4e293134c **/
//     AS_Button_b33c5c9b1b024100875de3d7fdff61cd: function AS_Button_b33c5c9b1b024100875de3d7fdff61cd(eventobject) {
//         var self = this;
//         return self.removeDragInteraction1.call(this);
//     },
//     /** preShow defined for Form9 **/
//     AS_Form_d0ad3bad10cf4a80b679f4e4f28483c2: function AS_Form_d0ad3bad10cf4a80b679f4e4f28483c2(eventobject) {
//         var self = this;
//         try {
//             this.formpreshow();
//         } catch (e) {
//             alert(JSON.stringify(e));
//         }
//     },
//     /** onClick defined for Button0d047f0559b6247 **/
//     AS_Button_f4e2f4d3495d46f9b9722a388d949079: function AS_Button_f4e2f4d3495d46f9b9722a388d949079(eventobject) {
//         var self = this;
//         return self.removeDropInteraction1.call(this);
//     }
// });
// define("Form9Controller", ["userForm9Controller", "Form9ControllerActions"], function() {
//     var controller = require("userForm9Controller");
//     var controllerActions = ["Form9ControllerActions"];
//     return kony.visualizer.mixinControllerActions(controller, controllerActions);
// });
