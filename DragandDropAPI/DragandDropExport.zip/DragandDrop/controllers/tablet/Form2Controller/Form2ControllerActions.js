define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** postShow defined for Form2 **/
    AS_Form_e611bf9079aa4f12a9b03cdd8b2c3995: function AS_Form_e611bf9079aa4f12a9b03cdd8b2c3995(eventobject) {
        var self = this;
        kony.application.destroyForm("frmHome");
        var ntf = new kony.mvc.Navigation("frmHome");
        ntf.navigate();
    }
});