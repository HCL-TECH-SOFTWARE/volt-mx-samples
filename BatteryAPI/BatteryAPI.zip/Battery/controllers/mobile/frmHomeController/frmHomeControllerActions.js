define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnGetLevel **/
    AS_Button_db2abbef2d4c40b1ada92302d8ec1781: function AS_Button_db2abbef2d4c40b1ada92302d8ec1781(eventobject) {
        var self = this;
        return self.getBatteryLevel.call(this);
    },
    /** onClick defined for btnGetState **/
    AS_Button_fd3864ca96394624bd751663c05e6557: function AS_Button_fd3864ca96394624bd751663c05e6557(eventobject) {
        var self = this;
        return self.getBatteryState.call(this);
    },
    /** onClick defined for btnRegisterBatteryService **/
    AS_Button_ca8bbccd20924aecb12688f4c5df9053: function AS_Button_ca8bbccd20924aecb12688f4c5df9053(eventobject) {
        var self = this;
        return self.registerBatteryService.call(this);
    }
});