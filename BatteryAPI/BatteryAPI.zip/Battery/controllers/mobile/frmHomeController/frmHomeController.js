define({ 
  getBatteryLevel: function()
  {
    kony.os.registerBatteryService(this.batterySuccessCallback);
    var battery = kony.os.getBatteryLevel();
    kony.os.unregisterBatteryService();
    this.view.lblDisplay.text = battery +"%";   
  },
   //This code is used to obtain your device battery state
  getBatteryState: function()
  {
    kony.os.registerBatteryService(this.batterySuccessCallback);
    var batteryState = kony.os.getBatteryState();
    if(kony.os.BATTERY_STATE_CHARGING == batteryState)
      {
        alert("The Device is charging");
          kony.os.unregisterBatteryService();
      }
    else if(kony.os.BATTERY_STATE_DISCHARGING == batteryState)
      {
        alert("The Device is discharging");
          kony.os.unregisterBatteryService();
      }
    else if(kony.os.BATTERY_STATE_FULL == batteryState)
      {
        alert("The Device is completely charged");
          kony.os.unregisterBatteryService();
      }
    else if(kony.os.BATTERY_STATE_UNKNOWN == batteryState)
      {
        alert("The Device charging state is unkonwn");
        kony.os.unregisterBatteryService();
      }
  },
   //This code is used to register a battery service and deregister the service based on your battery level
  registerBatteryService: function()
  { 
    kony.os.registerBatteryService(this.mybatterychangecallback);
    var batterylevel = kony.os.getBatteryLevel();
  }, 
  
  mybatterychangecallback: function(batteryInfo)
  {
   var batterylevel = batteryInfo.batterylevel;   
    if(batterylevel <= 20)
      {
       alert("The Battery Level is below 20%, make sure that you charge your device"); 
      }
    else
      {
        kony.os.unregisterBatteryService();
        alert("We are unregistering the Battery Service as it might cause an overhead");
      }
  },
  
  batterySuccessCallback: function(batteryInfo)
  {
    
  }
  

 });