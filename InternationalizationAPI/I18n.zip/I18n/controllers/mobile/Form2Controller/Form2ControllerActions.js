define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** postShow defined for Form2 **/
    AS_Form_d803c623fe21412fa83a065b0f0410e0: function AS_Form_d803c623fe21412fa83a065b0f0410e0(eventobject) {
        var self = this;
        kony.application.destroyForm("frmHome");
        var ntf = new kony.mvc.Navigation("frmHome");
        ntf.navigate();
    }
});