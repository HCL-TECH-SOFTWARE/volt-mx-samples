define({ 
/*By using this function, you set a locale based on your input that you select from the 
  list box widget.*/
 setlocaleListbox: function(){
   if(this.view.lstbx.selectedKey=="lb1")
     {
       kony.i18n.setCurrentLocaleAsync("en_GB",this.onsuccesscallback, this.onfailurecallback);
     }
    else if(this.view.lstbx.selectedKey=="lb2")
     {
       kony.i18n.setCurrentLocaleAsync("es_AR", this.onsuccesscallback, this.onfailurecallback);
     }
    else if(this.view.lstbx.selectedKey=="lb3")
     {
       kony.i18n.setCurrentLocaleAsync("fr_FR", this.onsuccesscallback, this.onfailurecallback);
     }
    },
//To get the Locale name that is currently set on your app 
 getCurrentLocale: function()
  {
        var currentLocales = kony.i18n.getCurrentLocale();
        alert("CurrentLocale :" + currentLocales);    
  },
//To get all the locales supported by the device  
  getSupportedLocale: function()
  {
  var supportedLocales = kony.i18n.getSupportedLocales();
  alert("Supported Locales :" + JSON.stringify(supportedLocales));
},
//To get the current device locale
  getCurrentDeviceLocale: function()
  {
     var locale = kony.i18n.getCurrentDeviceLocale();
     alert("current device locale is " + locale);
  },
//To get the localized string that corresponds to the specified i18n Key.  
  getLocalizedString: function()
  {
    var currentLocale = kony.i18n.getLocalizedString("Hello");
    alert(" LocalizedString Method called :" + currentLocale);
  },
//To set the default locale for your app.   
  setDefaultLocaleAsync: function()
  {
    kony.i18n.setDefaultLocaleAsync("fr_FR", this.onsuccesscallback, this.onfailurecallback);
  },
//To check whether the specified locale is supported by the device or not.  
  Checkthelocale: function()                 
  {
    var a = this.view.txtbx.text;
    if(kony.i18n.isLocaleSupportedByDevice("a")===true)
      {
        alert("This locale is supported");
      }
    else
      {
        alert("This Locale is not supported");
      }
  },
//To set a resource bundle for the key "Hello"
  setResourceBundle: function()
  {    
    kony.i18n.setResourceBundle({
      Hello: "Hallo Welt",
    }, "de_DE");
    kony.i18n.setCurrentLocaleAsync("de_DE",this.onsuccesscallback, this.onfailurecallback);  
  
  },
//To delete the resource bundle  
  deleteResourceBundle: function()
  {
    kony.i18n.deleteResourceBundle("de_DE");
    alert(" Resources bundle has been deleted.");
  },
  
//To update the resource bundle with a different text  
  updateResourceBundle: function()
{
 kony.i18n.updateResourceBundle({
           Hello: "Hallo Leute",
        }, "de_DE");
  kony.i18n.setCurrentLocaleAsync("de_DE",this.onsuccesscallback1, this.onfailurecallback);
},
  
 onsuccesscallback: function(oldLocaleName, newLocaleName)
{
if(newLocaleName=="en_GB")
  {
    alert("You have changed your locale to English");
  }
  else if(newLocaleName=="es_AR")
  {
    alert("You have changed your locale to Spanish");
  }
  else if(newLocaleName=="fr_FR")
  {
    alert("You have changed your locale to French");
  }
  else if(newLocaleName=="de_DE")
    {
      alert("You have set the resource bundle to German");
      this.view.lstbx.masterData.push(["lb4","German"]);
        /*= [
        ["lb1", "English"],
        ["lb2", "Spanish"],
        ["lb3", "French"],
        ["lb4", "German"]
    ];*/
    }
 },
 
  isResourceBundlePresent: function()
  {
    try {
        var exists = kony.i18n.isResourceBundlePresent("en_GB");
        alert("English resource bundle is present " + exists);
    } catch (i18nError) {
        alert("Exception While getting isResourceBundlePresent : " + i18nError);
    }
  },
  
onsuccesscallback1: function(oldLocaleName, newLocaleName)
  {
    if(newLocaleName=="de_DE")
    {
      alert("You have updated the German resource bundle");
    }
  },

  
   onfailurecallback: function()
  {
    alert("Please enter correct locale");
  }
  
 });