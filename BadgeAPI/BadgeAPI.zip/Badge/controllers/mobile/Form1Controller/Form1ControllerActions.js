define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onNavigate defined for Form1 **/
    onNavigate: function AS_Form_ab9016699ede4d72a98984a74161bf1c(eventobject) {
        var self = this;
        return self.createAppMenu.call(this);
    }
});