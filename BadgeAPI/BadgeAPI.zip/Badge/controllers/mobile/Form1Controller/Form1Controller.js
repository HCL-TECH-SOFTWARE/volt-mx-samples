define({ 




createAppMenu: function(){
	var appMenuItem1 = ["appmenuitemid1","Accounts", "option1.png", this.onClickMenuItem1];
    var appMenuItem2 = ["appmenuitemid2","Examination", "option2.png", this.onClickMenuItem2];
	var appMenu = [appMenuItem1, appMenuItem2];
	kony.application.createAppMenu("SampleAppMenu", appMenu, null, null);
	kony.application.setCurrentAppMenu("SampleAppMenu");
 kony.application.setAppMenuBadgeValue("SampleAppMenu", "appmenuitemid1", "4");
 kony.application.setAppMenuBadgeValue("SampleAppMenu", "appmenuitemid2" , "6");
  
},
  
  onClickMenuItem1: function(){
alert("The Badge Value of Accounts App Menu Item is " + kony.application.getAppMenuBadgeValue("SampleAppMenu","appmenuitemid1"));

},
  onClickMenuItem2: function(){
alert("The Badge Value of Examination App Menu Item is " + kony.application.getAppMenuBadgeValue("SampleAppMenu","appmenuitemid2"));
    
},
  
  
  
  

  
 });