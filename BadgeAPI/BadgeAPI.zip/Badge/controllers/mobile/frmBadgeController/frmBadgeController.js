define({ 

  settingBadge:function(  )
{
	this.view.btnBadge.setBadge("0","");//Set badge value on  button widget
  	kony.application.setApplicationBadgeValue(""+0);
},
   BadgeIncrease:function( )
{
	var counter = kony.os.toNumber(this.view.btnBadge.getBadge ()) + 1;// read badge value from button and increment it with 1 
	kony.print("this gets executed " + counter+ "type is "+typeof(counter));
	this.view.btnBadge.setBadge ("" + counter, "");// Set badge value on the button widget
	kony.application.setApplicationBadgeValue("" + counter);//Set badge value on app icon
},
  gettingBadge: function()
  {
    var badge = kony.application.getApplicationBadgeValue();
    alert("The badge value is " +badge);
},
  
  createAppMenu: function(){
	var appMenuItem1 = ["appmenuitemid1","Accounts", "option1.png", this.onClickMenuItem1];
    var appMenuItem2 = ["appmenuitemid2","Examination", "option2.png", this.onClickMenuItem2];
	var appMenu = [appMenuItem1, appMenuItem2];
	kony.application.createAppMenu("SampleAppMenu", appMenu, null, null);
	kony.application.setCurrentAppMenu("SampleAppMenu");
},
  
  onClickMenuItem1: function(){
alert("Accounts");
},
  onClickMenuItem2: function(){
alert("Examination");
},

 });