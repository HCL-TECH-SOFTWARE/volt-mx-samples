define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnBadge **/
    AS_Button_d4cbe27e1653498fb5a8db4517407542: function AS_Button_d4cbe27e1653498fb5a8db4517407542(eventobject) {
        var self = this;
        return self.BadgeIncrease.call(this);
    },
    /** onClick defined for btnGetBadge **/
    AS_Button_a50574bf216f47d0bf3ef0f4575cf199: function AS_Button_a50574bf216f47d0bf3ef0f4575cf199(eventobject) {
        var self = this;
        return self.gettingBadge.call(this);
    },
    /** onClick defined for btnAppMenu **/
    AS_Button_i4e2591f86c846e8bf8c686726794e0f: function AS_Button_i4e2591f86c846e8bf8c686726794e0f(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("Form1");
        ntf.navigate();
    },
    /** preShow defined for frmBadge **/
    AS_Form_ia3f092c989d4070b31545a13f1c725f: function AS_Form_ia3f092c989d4070b31545a13f1c725f(eventobject) {
        var self = this;
        return self.settingBadge.call(this);
    }
});