define({ 

 //Type your controller code here 
  
  addContact:function()
{
var result = kony.application.checkPermission(kony.os.RESOURCE_CONTACTS);
if (result.status==kony.application.PERMISSION_DENIED)
  {
    kony.application.requestPermission(kony.os.RESOURCE_CONTACTS, this.callback);
  } else{
  var mycontact = {
						firstname :"John",lastname :"Steve",
						phone:[{name:"mobile",number:"9999999999"},{name:"home",number:"9999999999"}],
						email:[{name:"home",id:"abc@yahoo.com"},{name:"work",id:"def@kony.com"}],
						postal:[{name:"home",street:"Raheja",city:"hyderabad",state:"AP",zipcode:"500310"}],
						company:[{name:"work",company:"kony",title:"architect"}]
				        };
		kony.contact.add(mycontact);
		alert("The contact John is successfully added");
}
},
  callback: function()
  {
    kony.application.openApplicationSettings();
  }

 });