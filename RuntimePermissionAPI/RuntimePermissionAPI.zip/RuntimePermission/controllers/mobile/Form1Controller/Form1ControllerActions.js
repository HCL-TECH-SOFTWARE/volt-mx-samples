define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnAddContact **/
    AS_Button_e489b70d0ab9453995da0292ae66e8fb: function AS_Button_e489b70d0ab9453995da0292ae66e8fb(eventobject) {
        var self = this;
        return self.addContact.call(this);
    }
});