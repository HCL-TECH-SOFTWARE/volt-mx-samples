define({ 

//Creating the Action Item Object
  setActionSheet: function(){
    var actionItem = new kony.ui.ActionItem({
    "title": "Open Base Camp",
    "style": constants.ACTION_STYLE_DEFAULT,
    "action": function(){
     kony.application.openURL("https://basecamp.kony.com/s/");
    }
}); 
    //Creating the Action Sheet Object
  var actionSheetObject = new kony.ui.ActionSheet({
        "title":"Kony Base Camp", 
        "message":"Welcome to Kony Base Camp! Explore. Learn. Develop. Share.", 
        "showCompletionCallback": function(){
        }
    });
//Adding action to the Action Sheet object    
actionSheetObject.addAction(actionItem);
//Displaying the Action Sheet    
actionSheetObject.show();
  }
  
 });