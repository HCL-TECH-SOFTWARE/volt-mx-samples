define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnActionSheet **/
    AS_Button_g218eaa450784ea48ca444e0a0816010: function AS_Button_g218eaa450784ea48ca444e0a0816010(eventobject) {
        var self = this;
        return self.setActionSheet.call(this);
    }
});