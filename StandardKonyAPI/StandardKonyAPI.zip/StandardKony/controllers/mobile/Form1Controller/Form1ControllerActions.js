define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onCapture defined for Camera1 **/
    AS_Camera_a0403e7016354f729118c79958884b94: function AS_Camera_a0403e7016354f729118c79958884b94(eventobject) {
        var self = this;
        var rawBytes = this.view.Camera1.rawBytes;
        this.view.image1.rawBytes = rawBytes;
    },
    /** onClick defined for btnBase64 **/
    AS_Button_c148c141e85b484cbb8333b70e7afe51: function AS_Button_c148c141e85b484cbb8333b70e7afe51(eventobject) {
        var self = this;
        return self.convertToBase64.call(this);
    },
    /** onClick defined for btnError **/
    AS_Button_j5825ce6856c42f080e01757f369ea3b: function AS_Button_j5825ce6856c42f080e01757f369ea3b(eventobject) {
        var self = this;
        return self.getError.call(this);
    },
    /** onClick defined for btnRawBytes **/
    AS_Button_g94550903bd84d0bb9c9f160ffb53654: function AS_Button_g94550903bd84d0bb9c9f160ffb53654(eventobject) {
        var self = this;
        return self.convertBackToRawBytes.call(this);
    },
    /** onClick defined for btnType **/
    AS_Button_jda49e9a54b74da3a28544d662a120cc: function AS_Button_jda49e9a54b74da3a28544d662a120cc(eventobject) {
        var self = this;
        return self.type.call(this);
    },
    /** onClick defined for btnPrint **/
    AS_Button_f0264c2f820d4cd9a15b35202fa972d9: function AS_Button_f0264c2f820d4cd9a15b35202fa972d9(eventobject) {
        var self = this;
        return self.print.call(this);
    }
});