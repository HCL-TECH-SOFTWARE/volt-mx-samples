define({ 

 //Type your controller code here 
convertToBase64: function()
  {
    var rBytes = this.view.image1.rawBytes;
    var base = kony.convertToBase64(rBytes);
    this.view.image2.base64 =base; 
   alert("The image is converted from RawBytes format to Base64 format ");
  },
  
  convertBackToRawBytes: function()
  {
  var base = this.view.image2.base64;
  var rBytes = kony.convertToRawBytes(base);
  this.view.image2.rawBytes=rBytes;
  alert("The image is again converted back to RawBytes");  
},
  
  getError: function()
  {
    
    try {
      var i = kony.os.deviceinfo();//We have provided a wrong function intentionally
      alert("The device info " +i);
} catch (e) {
    var err = kony.getError(e);
alert("The error is as follows "+err);
}
  },
  
  print: function()
  {
    kony.print("Srija is great");
  },
  
  type: function()
  {
    var type= this.view.txtbox.text;
    alert("The type of the variable is "+kony.type(type));
  },
  
  
 });