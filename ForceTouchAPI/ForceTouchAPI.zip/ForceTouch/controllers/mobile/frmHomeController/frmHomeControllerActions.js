define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0g7cec1fe79fa49 **/
    AS_Button_d3c0cae5ee544a249be27a414072b09b: function AS_Button_d3c0cae5ee544a249be27a414072b09b(eventobject) {
        var self = this;
        return self.setDynQANormalTitle.call(this);
    },
    /** onClick defined for Button0c50504d5000742 **/
    AS_Button_ffbb795605dc48319d175741b6375734: function AS_Button_ffbb795605dc48319d175741b6375734(eventobject) {
        var self = this;
        return self.removeDynQAItems.call(this);
    },
    /** onClick defined for Button0fcb5161c94c042 **/
    AS_Button_f8ac8ea3185748a88719f0fd083045de: function AS_Button_f8ac8ea3185748a88719f0fd083045de(eventobject) {
        var self = this;
        return self.enableDynQAItems.call(this);
    },
    /** onClick defined for Button0d42493a013b440 **/
    AS_Button_cfa90c136ea94f90bf9e7121c0252ab8: function AS_Button_cfa90c136ea94f90bf9e7121c0252ab8(eventobject) {
        var self = this;
        return self.disableDynQAItems.call(this);
    },
    /** onClick defined for Button0hbef34ffab7440 **/
    AS_Button_efc93581008041d2b1f270b971519a2f: function AS_Button_efc93581008041d2b1f270b971519a2f(eventobject) {
        var self = this;
        return self.getDynQAItems.call(this);
    },
    /** onClick defined for Button0gd0c7f263e8e42 **/
    AS_Button_c34da7d1d824455c93732453e16b857b: function AS_Button_c34da7d1d824455c93732453e16b857b(eventobject) {
        var self = this;
        return self.getPinnedDynQIItems.call(this);
    },
    /** onClick defined for Button0dfcff972a37c47 **/
    AS_Button_f1203332e9844ae8ab94f54e9dce67fd: function AS_Button_f1203332e9844ae8ab94f54e9dce67fd(eventobject) {
        var self = this;
        return self.getStaticDynQIItems.call(this);
    }
});