define({ 
 
// To set dynamic quick action Item to your app. 
  setDynQANormalTitle: function() {
    try {
        var success = kony.forcetouch.setQuickActionItems([{
            "id": "com.kony.first",
            "title": "firstPage",
            "subtitle": "takes to first page",
            "icon": kony.forcetouch.QUICK_ACTION_ICON_TYPE_COMPOSE,
            "info": {
                "feed": "feed to first form"
            }
        }]);
        alert("Status: " + success + ". " + "Normal title & subtitle are set");
    } catch (args) {
        alert(args.toString());
    }
},
//To get an array of dynamic quick action item details.   
 getDynQAItems:  function () {
    try {
        var quickActionItems = kony.forcetouch.getQuickActionItems();
        alert(quickActionItems);
    } catch (args) {
        alert(args.toString());
    }
},
//To remove all the dynamic quick action items from the app.   
 removeDynQAItems:  function() {
    try {
        kony.forcetouch.removeQuickActionItems();
      alert("Dynamic QA items are removed");
    } catch (args) {
        alert(args.toString());
    }
},
//To enable the pinned shortcuts that were disabled earlier.
    enableDynQAItems:  function() {
var shortcuts = ["com.kony.first"];
    kony.forcetouch.enableQuickActionItems(shortcuts);
},
//To disable the shortcuts that are pinned to the home screen.  
  disableDynQAItems:  function() {
    
var shortcuts = {"com.kony.first":"disable1"};
    kony.forcetouch.disableQuickActionItems(shortcuts,"disabled all shortcuts");
},
//To get the list of all pinned action items that you set on your home screen.  
  getPinnedDynQIItems: function()
{
  var pinnedQuickActionArray=kony.forcetouch.getPinnedQuickActionItems();
  alert("The pinned quick action Items are:"+pinnedQuickActionArray);
  },
//To get the list of an array of immutable or static quick action items.
  getStaticDynQIItems: function()
  {
    var staticQuickActionArray = kony.forcetouch.getStaticQuickActionItems();
    alert("The static quick action Items are:" + staticQuickActionArray);
  }
  

 });