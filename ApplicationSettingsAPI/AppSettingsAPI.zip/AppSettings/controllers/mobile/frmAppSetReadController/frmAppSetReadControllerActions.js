define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for headerButtonLeft **/
    AS_Button_b99e488b8a57487b9a9b2b425dcbf3f4: function AS_Button_b99e488b8a57487b9a9b2b425dcbf3f4(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmAppSettings");
        ntf.navigate();
    }
});