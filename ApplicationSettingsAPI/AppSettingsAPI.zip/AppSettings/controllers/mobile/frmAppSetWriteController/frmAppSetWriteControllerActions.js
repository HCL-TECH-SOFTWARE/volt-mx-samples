define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for headerButtonLeft **/
    AS_Button_a8efd16b3bc9418eae93970fbde84c43: function AS_Button_a8efd16b3bc9418eae93970fbde84c43(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmAppSettings");
        ntf.navigate();
    },
    /** onClick defined for btnSetAppSetngs **/
    AS_Button_a289ad0d5cf34d1aaa70203c496dd41d: function AS_Button_a289ad0d5cf34d1aaa70203c496dd41d(eventobject) {
        var self = this;
        return self.write.call(this);
    }
});