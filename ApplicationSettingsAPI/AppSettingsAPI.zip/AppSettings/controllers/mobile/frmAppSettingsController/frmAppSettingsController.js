define({ 

 //Type your controller code here
  
   read :function()
{
	
	kony.application.settings.read ("key1", this.onsuccesscallbackR, this.onfailureback);
	kony.application.settings.read ("key2", this.onsuccesscallbackR, this.onfailurebackR);
},
    
 onfailureback:function(errorcode,errormessage)
{
	alert("err is :"+errormessage);	
},
 onsuccesscallbackR:function(key,value)
{
	var params={};	
  	params.value = value;
	
		switch(value)
		{
			case "Table view":
							params.viewType = constants.SEGUI_VIEW_TYPE_TABLEVIEW;
							break;
			case "Page view":
							params.viewType = constants.SEGUI_VIEW_TYPE_PAGEVIEW;
							params.pageOffDotImage = "orngsld";
							params.pageOnDotImage = "whitesld";
							break;
			case "Coverflow view":
							params.viewType = constants.SEGUI_VIEW_TYPE_COVERFLOW;
							break;
			case "Cylinder view":
							params.viewType = constants.SEGUI_VIEW_TYPE_CYLINDER;
							break;
			case "Linear view":
							params.viewType = constants.SEGUI_VIEW_TYPE_LINEAR;
							break;
			case "Stack view":
							params.viewType = constants.SEGUI_VIEW_TYPE_STACK;
							break;								
			
		}
  	var ntf=new kony.mvc.Navigation("frmAppSetRead");
	ntf.navigate(params);
},

 onfailurebackR:function(errorcode,errormessage)
{
	alert("Err is :"+errormessage);
}

 });