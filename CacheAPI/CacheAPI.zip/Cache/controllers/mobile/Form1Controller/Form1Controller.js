define({ 

 //Type your controller code here 
  
  //Sample code to set the memory and disk capacity
  setMemoryandDiskCapacity: function()
  {
    var memory=this.view.tbxMemory.text;
    var disk= this.view.tbxDisk.text;
    kony.net.cache.setMemoryAndDiskCapacity(memory, disk);
    alert("The Memory and Disk Capacity is set");
  },
  //Sammple code to get the memory capacity
 getMemoryCapacity: function()
  {
    var memoryCapacity = kony.net.cache.getMemoryCapacity();
    alert("The memory capacity of the device is: "+ memoryCapacity +"B");
  },
  //Sample code to get the disk capacity 
 getDiskCapacity: function()
  {
    var diskCapacity = kony.net.cache.getDiskCapacity();
    alert("The disk capacity of the device is: " + diskCapacity +"B");
  },
  //Sample code to get the current disk usage
 currentDiskUsage: function()
  {
  var diskUsage = kony.net.cache.getCurrentDiskUsage();
  alert("The current disk usage is: " + diskUsage); 
},
  //Sample code to get the current memory usage
 currentMemoryUsage: function()
  {
    var memUsage = kony.net.cache.getCurrentMemoryUsage();
    alert("The current memory usage is: " + memUsage);
  },
  //Sample code to set Cache config
  setCacheConfig: function()
  {
    var cacheConfig = {
      cachePolicy: kony.net.cache.USE_PROTOCOL_CACHE_POLICY, //Setting the Cache policy 
      cacheStoragePolicy: kony.net.cache.DISK_AND_MEMORY // Setting the Cache Storage Policy
    };
    var cache = kony.net.cache.setCacheConfig(cacheConfig);
    alert("The Cache Config is set ");
}
  
 });