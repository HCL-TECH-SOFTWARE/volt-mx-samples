define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnSetMemoryAndDisk **/
    AS_Button_bb41151bf75247899c828b0a549f863a: function AS_Button_bb41151bf75247899c828b0a549f863a(eventobject) {
        var self = this;
        return self.setMemoryandDiskCapacity.call(this);
    },
    /** onClick defined for btnGetMemory **/
    AS_Button_baf0a7505f9a44e8948c8b0fbf9851ae: function AS_Button_baf0a7505f9a44e8948c8b0fbf9851ae(eventobject) {
        var self = this;
        return self.getMemoryCapacity.call(this);
    },
    /** onClick defined for btnGetDisk **/
    AS_Button_h8306d48c64247be9e1ddafbd5571adb: function AS_Button_h8306d48c64247be9e1ddafbd5571adb(eventobject) {
        var self = this;
        return self.getDiskCapacity.call(this);
    },
    /** onClick defined for btnGetCurrentDisk **/
    AS_Button_j040cfa6ba07448c8bb474295ac0a43a: function AS_Button_j040cfa6ba07448c8bb474295ac0a43a(eventobject) {
        var self = this;
        return self.currentDiskUsage.call(this);
    },
    /** onClick defined for btnGetCurrentMemory **/
    AS_Button_ef487e76a63845babbe970f0dbcccaf4: function AS_Button_ef487e76a63845babbe970f0dbcccaf4(eventobject) {
        var self = this;
        return self.currentMemoryUsage.call(this);
    },
    /** onClick defined for btnSetCacheConfig **/
    AS_Button_b1224d9e10b4444db19fe33daad41355: function AS_Button_b1224d9e10b4444db19fe33daad41355(eventobject) {
        var self = this;
        return self.setCacheConfig.call(this);
    }
});