define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnContinue **/
    AS_Button_db191fcc964649dda8efd10a0bf5cbbd: function AS_Button_db191fcc964649dda8efd10a0bf5cbbd(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmOptions");
        ntf.navigate();
    },
    /** onClick defined for btnFramework **/
    AS_Button_df4ee3a9e2c94e7294b944dbe8429932: function AS_Button_df4ee3a9e2c94e7294b944dbe8429932(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmKnowledgeFramework");
        ntf.navigate();
    }
});