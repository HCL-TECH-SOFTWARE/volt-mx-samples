define({ 

  //Type your controller code here 
  addbookmark: function()
  {

    kony.application.addBMState("Form1", "About", "page2");
    alert("A specified key and value are added to the parameter list of the URL");

  },

  getbookmark: function()
  {

    var a = kony.application.getBMState("Form1");
    alert(" The list of parameters attached to the URL are " +JSON.stringify(a));    

  },

  removebookmark: function()
  {
    kony.application.removeBMState ("Form1", "About");
    alert("The About key is removed from the parameter list");
  },

  setState: function(){

    var state = {
      Bookmark: "about",
      text: "About"
    };
    kony.application.setBMState("Form1", state);
    alert("A new state is set to the URL ");
  }, 

  resetBookmarkState: function(){
    kony.application.resetBMState ("Form1");
    alert("The state is removed from the URL");
  }
});