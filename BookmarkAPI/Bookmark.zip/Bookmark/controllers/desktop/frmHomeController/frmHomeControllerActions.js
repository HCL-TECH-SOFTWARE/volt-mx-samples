define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnAddState **/
    AS_Button_eb1dddf4be1e4f40968d582e11f1a2ff: function AS_Button_eb1dddf4be1e4f40968d582e11f1a2ff(eventobject) {
        var self = this;
        return self.addbookmark.call(this);
    },
    /** onClick defined for btnGetState **/
    AS_Button_a8653c69f19843aea06e23594e685cf4: function AS_Button_a8653c69f19843aea06e23594e685cf4(eventobject) {
        var self = this;
        return self.getbookmark.call(this);
    },
    /** onClick defined for removeState **/
    AS_Button_f5d883423064444999a3cb9b61f10def: function AS_Button_f5d883423064444999a3cb9b61f10def(eventobject) {
        var self = this;
        return self.removebookmark.call(this);
    },
    /** onClick defined for setState **/
    AS_Button_b218628fff964b40a8a084589bc9b59a: function AS_Button_b218628fff964b40a8a084589bc9b59a(eventobject) {
        var self = this;
        return self.setState.call(this);
    },
    /** onClick defined for resetState **/
    AS_Button_d67bb570b8f5450db7afcffafbdd6b33: function AS_Button_d67bb570b8f5450db7afcffafbdd6b33(eventobject) {
        var self = this;
        return self.resetBookmarkState.call(this);
    }
});