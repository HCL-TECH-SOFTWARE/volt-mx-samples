define({
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
    /** postShow defined for frmKnowledgeFramework **/
    AS_Form_ffeb2b471a254051851f3d30816428fd: function AS_Form_ffeb2b471a254051851f3d30816428fd(eventobject) {
        var self = this;
        this.knwledgedContent();
    }
});