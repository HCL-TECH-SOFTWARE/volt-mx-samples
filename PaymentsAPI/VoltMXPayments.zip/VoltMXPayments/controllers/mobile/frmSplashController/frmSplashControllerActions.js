define({
    /*
          This is an auto generated file and any modifications to it may result in corruption of the action sequence.
        */
    /** preShow defined for frmSplash **/
    AS_Form_a7608571054a4d4db46d4f0c05cf24a7: function AS_Form_a7608571054a4d4db46d4f0c05cf24a7(eventobject) {
        var self = this;
        this.setGetStartedData();
    }
});