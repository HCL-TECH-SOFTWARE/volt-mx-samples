define({
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_AppEvents_h33e2953ae484458a14b2fb23ecc383e: function AS_AppEvents_h33e2953ae484458a14b2fb23ecc383e(eventobject) {
        var self = this;
        //#ifdef android
        kony.application.registerOnSettingsChangeCallback(["wifi"], deviceSettingCallback);
        //#endif
    }
});