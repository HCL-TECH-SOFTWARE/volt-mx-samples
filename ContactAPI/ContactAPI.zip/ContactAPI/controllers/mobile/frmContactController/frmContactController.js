define({ 
//Use the below function to add a contact to your device.
 addContact:function()
{
	try
	{
      
      //Contact Details.
		var mycontact = {
						"firstname" :"John","lastname" :"Steve",
						"phone":[{"name":"mobile","number":"9999999999"},{"name":"home","number":"9999999999"}],
						"email":[{"name":"home","id":"abc@yahoo.com"},{"name":"work","id":"def@kony.com"}],
						"postal":[{"name":"home","street":"Raheja","city":"hyderabad","state":"AP","zipcode":"500310"}],
						"company":[{"name":"work","company":"kony","title":"Technical Writer"}]
				        };
        //Adding the contact to your device.
		kony.contact.add(mycontact);
		this.view.lblDevContact.text = "Contact is added with firstname = 'John' and lastname = 'Steve' . Please Check the device contacts.";
	}
	catch(err)
	{
		kony.print("error is ::: "+err);
	}
},

//Use the below function to find a contact from your list of contacts.
 findContact:function()
{
	var findContacts = kony.contact.find("John"); 
	if (findContacts === null ||findContacts ==="" ||findContacts === undefined )
	{
		this.view.lblDevContact.text = "No contacts with the first name is 'John' ";
	}
	else
	{
		var len = findContacts.length;
		this.view.lblDevContact.text = "No of contacts of which the first name is 'John' = "+len+".";
	}
},
  //Use the below function to retrieve the contact details.
  getDetails: function()
  {
    //Finding the contact whose details are to be retrieved.
    var findContacts= kony.contact.find("John");
    	if (findContacts === null ||findContacts ==="" ||findContacts === undefined )
	{
		this.view.lblDevContact.text = "No contacts with the first name is 'John' ";
	}
    else
      {//Retrieving the contact details.
        for (var i in findContacts )
          {
       var a=kony.contact.details(findContacts[i]) ;  
        this.view.lblDevContact.text = JSON.stringify(a);
      }
      }
    
  },
  
  //Use the below function to remove a contact from your contact list.
 removeContact:function()
{
  //Finding the contact.
	var findContacts = kony.contact.find("John"); 
	if (findContacts === null ||findContacts ==="" ||findContacts === undefined )
	{
		this.view.lblDevContact.text = "No contacts with the first name is 'John' ";
	}
	else
	{
      //Removing the contact.
		for (var i in findContacts )
			kony.contact.remove(findContacts[i]);
		this.view.lblDevContact.text = "Removed all contacts of which the first name is 'John' . Please Check the device contacts.";
	}
}

 });