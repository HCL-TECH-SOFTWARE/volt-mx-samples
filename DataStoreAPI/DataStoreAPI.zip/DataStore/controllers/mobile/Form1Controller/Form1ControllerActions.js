define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0d541dbcb65c747 **/
    AS_Button_e9261b30d2f94a9bafc7cc47bac4c030: function AS_Button_e9261b30d2f94a9bafc7cc47bac4c030(eventobject) {
        var self = this;
        return self.saveData.call(this);
    },
    /** onClick defined for Button0j9eed28e5f7f4c **/
    AS_Button_df82a3ee4cae4d849a7c7fa3f43f6cb0: function AS_Button_df82a3ee4cae4d849a7c7fa3f43f6cb0(eventobject) {
        var self = this;
        return self.readData.call(this);
    },
    /** onClick defined for Button0c7995646836149 **/
    AS_Button_be2e2ca9fb8e45899ba26b2f315a783c: function AS_Button_be2e2ca9fb8e45899ba26b2f315a783c(eventobject) {
        var self = this;
        return self.removeData.call(this);
    }
});