define({ 

 //Type your controller code here 
  saveData: function()
  {
    kony.ds.save( ["John", "Tom", "Harry"], "friends",{dsmode:"session"});
    alert("Data is saved to a table");
  },
  
  readData: function()
  {
   var a = kony.ds.read("friends");
   alert("The data stored in the table is " +a ); 
  },
 removeData: function()
  {
    kony.ds.remove("friends"); 
    alert("The data is removed from the table");
  }
 });