define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onSwipe defined for segCarousel2 **/
    AS_Segment_fef71752b88f4731bc424fd6909d6e4c: function AS_Segment_fef71752b88f4731bc424fd6909d6e4c(seguiWidget, sectionIndex, rowIndex) {
        var self = this;
        this.onSwipe(rowIndex);
    },
    /** onTouchStart defined for flxBookHotel **/
    AS_FlexContainer_b29fd22e97494c6a8ff69c2e2711b50a: function AS_FlexContainer_b29fd22e97494c6a8ff69c2e2711b50a(eventobject, x, y) {
        var self = this;
        this.bookHotel();
    },
    /** postShow defined for CardNoPeek **/
    AS_FlexContainer_j7324ca7190b46e5a03bbd83a42b781d: function AS_FlexContainer_j7324ca7190b46e5a03bbd83a42b781d(eventobject) {
        var self = this;
        this.mapValue();
    }
});