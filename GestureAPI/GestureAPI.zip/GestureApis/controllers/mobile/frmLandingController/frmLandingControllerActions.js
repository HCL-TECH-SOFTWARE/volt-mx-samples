define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onRowClick defined for segFeatureOptions **/
    AS_Segment_df34f2ee6d1344f3a84af71d0c4b0579: function AS_Segment_df34f2ee6d1344f3a84af71d0c4b0579(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.featureSelected();
    },
    /** onClick defined for Button0c4ad1989651943 **/
    AS_Button_ca7c717eb8c44fc8ae09b76240bedc22: function AS_Button_ca7c717eb8c44fc8ae09b76240bedc22(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmKnowledgeFramework");
        ntf.navigate(this.kfdata);
    }
});