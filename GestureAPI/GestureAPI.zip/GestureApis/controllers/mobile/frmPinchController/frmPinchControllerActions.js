define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0c4ad1989651943 **/
    AS_Button_cbe07d26d90c4c5bbc576cbf03740452: function AS_Button_cbe07d26d90c4c5bbc576cbf03740452(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmKnowledgeFramework");
        ntf.navigate();
    },
    /** postShow defined for frmPinch **/
    AS_Form_c649159c9f3943918b897ce67b8fee8c: function AS_Form_c649159c9f3943918b897ce67b8fee8c(eventobject) {
        var self = this;
        this.addPinchGesture();
    }
});