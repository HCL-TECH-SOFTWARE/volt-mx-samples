define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0c4ad1989651943 **/
    AS_Button_d214db0a9e0b413380591c1435c18e25: function AS_Button_d214db0a9e0b413380591c1435c18e25(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmKnowledgeFramework");
        ntf.navigate();
    },
    /** postShow defined for frmRotation **/
    AS_Form_a06b5634e72142eda0df5031600fd62b: function AS_Form_a06b5634e72142eda0df5031600fd62b(eventobject) {
        var self = this;
        this.addRotateGesture();
    }
});