define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0c4ad1989651943 **/
    AS_Button_e9b82b93bc784b4d898db730d22ab5ef: function AS_Button_e9b82b93bc784b4d898db730d22ab5ef(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmKnowledgeFramework");
        ntf.navigate();
    },
    /** postShow defined for frmPan **/
    AS_Form_c24a4d4329f1413a95e16b4509283368: function AS_Form_c24a4d4329f1413a95e16b4509283368(eventobject) {
        var self = this;
        this.addPanGesture();
    }
});