//Type your code here
 g_zoomIn = 50;
	g_zoomOut = 50;
	g_scaleStart = 0;
	g_scaleEnd = 0;