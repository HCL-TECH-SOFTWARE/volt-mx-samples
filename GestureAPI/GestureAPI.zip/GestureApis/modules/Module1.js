//Type your code here
var data=[];