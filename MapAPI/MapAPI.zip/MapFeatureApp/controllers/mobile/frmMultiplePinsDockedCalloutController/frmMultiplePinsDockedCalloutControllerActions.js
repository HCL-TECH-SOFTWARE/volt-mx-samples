define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for headerButtonLeft **/
    AS_Button_aade1231841f4e66bc701cd25cf2c627: function AS_Button_aade1231841f4e66bc701cd25cf2c627(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmProperties");
        ntf.navigate();
    },
    /** onHide defined for frmMultiplePinsDockedCallout **/
    AS_Form_c2f5393979274dca9262b98feff4e9af: function AS_Form_c2f5393979274dca9262b98feff4e9af(eventobject) {
        var self = this;
        kony.application.destroyForm("frmMultiplePinsDockedCallout");
    }
});