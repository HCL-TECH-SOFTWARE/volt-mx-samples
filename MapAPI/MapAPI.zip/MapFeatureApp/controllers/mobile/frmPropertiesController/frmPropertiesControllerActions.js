define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onRowClick defined for segFeatureOptions **/
    AS_Segment_ebd4729e9b6c416580b2199c9cdbef09: function AS_Segment_ebd4729e9b6c416580b2199c9cdbef09(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.featureSelected();
    },
    /** onTouchEnd defined for headerIconLeft **/
    AS_Label_d356ed7362ec4159a97102c426ccd8db: function AS_Label_d356ed7362ec4159a97102c426ccd8db(eventobject, x, y) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLanding");
        ntf.navigate();
    }
});