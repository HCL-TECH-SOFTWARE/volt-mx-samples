define({ 

//Defining pin 1.  
  addPins: function()
  {
var pin1 = {
    id: "id1", // id is mandatory for every pin in dictionary
    lat: "17.4947934",
    lon: "78.3996441",
    name: "KPHB",
    image: "pinb.png",
    focusImage: "focusImage.png", //focus image will be shown while map pin selected
    desc: "Kukatpally",
    showCallout: true,
    meta: {
        color: "green",
        label: "A"
    }
};
//Defining pin 2.
var pin2 = {
    id: "id2", // id is mandatory for every pin in dictionary
    lat: "17.3616",
    lon: "78.4747",
    name: "Charminar",
    image: "pinb.png",
    focusImage: "focusImage.png",
    //focus image will be shown while map pin selected
    desc: "In Hyderabad",
    showCallout: true,
    meta: {
        color: "green",
        label: "B"
    }
};

//Adding pins.
this.view.MainMap.addPins([pin1, pin2]);
//Calculating the distance between the two pins.    
var distanceInMeters = kony.map.distanceBetween(pin1, pin2);	
    alert("The distance in meters is "+distanceInMeters);
  }
  
 
 });