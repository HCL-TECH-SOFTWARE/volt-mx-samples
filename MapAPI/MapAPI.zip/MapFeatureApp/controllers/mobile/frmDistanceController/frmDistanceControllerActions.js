define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnDistance **/
    AS_Button_i8ff47cb72114b4f9429604d17bf3715: function AS_Button_i8ff47cb72114b4f9429604d17bf3715(eventobject) {
        var self = this;
        return self.addPins.call(this);
    },
    /** onClick defined for headerButtonLeft **/
    AS_Button_fe4a2f1457c3490b9d9d8348de5eac20: function AS_Button_fe4a2f1457c3490b9d9d8348de5eac20(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmAPIs");
        ntf.navigate();
    }
});