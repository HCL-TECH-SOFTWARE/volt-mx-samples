define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for headerButtonLeft **/
    AS_Button_a240aaa04ba447688597579b4055ea57: function AS_Button_a240aaa04ba447688597579b4055ea57(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmProperties");
        ntf.navigate();
    }
});