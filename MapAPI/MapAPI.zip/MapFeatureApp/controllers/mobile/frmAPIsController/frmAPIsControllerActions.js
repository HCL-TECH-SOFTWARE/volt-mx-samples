define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnDistance **/
    AS_Button_c3b0bf516f8046d2ad71eda8da1fa80e: function AS_Button_c3b0bf516f8046d2ad71eda8da1fa80e(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmDistance");
        ntf.navigate();
    },
    /** onClick defined for btnLocation **/
    AS_Button_b7f7f30c9fec401cb94519d359613475: function AS_Button_b7f7f30c9fec401cb94519d359613475(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmContainsLocation");
        ntf.navigate();
    },
    /** onClick defined for btnSearchRoutes **/
    AS_Button_d860c52e5f674962800edc72475b5516: function AS_Button_d860c52e5f674962800edc72475b5516(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmSearchRoutes");
        ntf.navigate();
    },
    /** onClick defined for headerButtonLeft **/
    AS_Button_fe4eff222d184cf9b110c94c01eb5e8e: function AS_Button_fe4eff222d184cf9b110c94c01eb5e8e(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLanding");
        ntf.navigate();
    }
});