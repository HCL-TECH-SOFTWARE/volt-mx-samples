define({ 
  addCircle: function()
  {
    //Defining a circular area
    var testdata = {
    id: "circleId",
    centerLocation: {
        lat: "17.451759",
        lon: "78.380806"
    },
    navigatetoZoom: true,
    radius: 1000,
    circleConfig: {
        lineColor: "0x7D664DFF",
        lineWidth: 5
    },
    showCenterPin: true
};
//Adding the circel onto the map widget    
this.view.Map2.addCircle(testdata); 
  },
    containsLocation: function(){
//Defining the shapeData parameter      
    var shapeData = {
    locations: [{
        lat: "17.451759", 
        lon: "78.380806"
    }],
    radius: 1000
};
//Definign the location parameter
    var location ={
      lat: "17.451759", 
      lon: "78.380806"
    };
//Checking if the location mentioned falls inside the circle or not            
var b = kony.map.containsLocation(kony.map.SHAPE_TYPE_CIRCLE, location, shapeData);	
    if(b===true)
      {
        alert("The location falls inside the circle");
      }
    else
      {
        alert("The location does not fall inside the circle");
      }
}

 });