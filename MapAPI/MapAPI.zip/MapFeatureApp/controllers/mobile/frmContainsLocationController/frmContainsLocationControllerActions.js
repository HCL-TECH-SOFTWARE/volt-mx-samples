define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnLocation **/
    AS_Button_fae3e424dd0d4dd0a4097a99412d6df7: function AS_Button_fae3e424dd0d4dd0a4097a99412d6df7(eventobject) {
        var self = this;
        return self.containsLocation.call(this);
    },
    /** onClick defined for headerButtonLeft **/
    AS_Button_jaf153c879674ed0928fa533bd5c217a: function AS_Button_jaf153c879674ed0928fa533bd5c217a(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLanding");
        ntf.navigate();
    },
    /** preShow defined for frmContainsLocation **/
    AS_Form_f340c65d98c5420f88b87ab8423ea420: function AS_Form_f340c65d98c5420f88b87ab8423ea420(eventobject) {
        var self = this;
        return self.addCircle.call(this);
    }
});