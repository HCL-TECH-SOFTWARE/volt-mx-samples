function AS_Button_b352d962feb54c5899ab29ab87b36b0e(eventobject) {
    var ntf = new kony.mvc.Navigation("frmProperties");
    ntf.navigate();
}