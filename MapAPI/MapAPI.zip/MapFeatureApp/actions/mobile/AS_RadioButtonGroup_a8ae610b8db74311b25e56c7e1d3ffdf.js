function AS_RadioButtonGroup_a8ae610b8db74311b25e56c7e1d3ffdf(eventobject) {
    this.view.Map1.addPolygon(this.polyData);
}