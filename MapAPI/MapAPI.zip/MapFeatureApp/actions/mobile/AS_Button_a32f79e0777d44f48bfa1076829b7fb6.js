function AS_Button_a32f79e0777d44f48bfa1076829b7fb6(eventobject) {
    var ntf = new kony.mvc.Navigation("frmProperties");
    ntf.navigate();
}