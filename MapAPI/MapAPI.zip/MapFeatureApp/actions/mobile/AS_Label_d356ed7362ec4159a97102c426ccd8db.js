function AS_Label_d356ed7362ec4159a97102c426ccd8db(eventobject, x, y) {
    var ntf = new kony.mvc.Navigation("frmLanding");
    ntf.navigate();
}