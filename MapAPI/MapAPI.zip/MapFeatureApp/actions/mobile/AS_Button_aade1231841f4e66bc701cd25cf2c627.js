function AS_Button_aade1231841f4e66bc701cd25cf2c627(eventobject) {
    var ntf = new kony.mvc.Navigation("frmProperties");
    ntf.navigate();
}