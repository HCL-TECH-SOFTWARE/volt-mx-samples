function AS_Button_b5b3c45a994a434c82859afb4e001f11(eventobject) {
    var ntf = new kony.mvc.Navigation("frmProperties");
    ntf.navigate();
}