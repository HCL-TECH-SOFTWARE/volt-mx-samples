function AS_Button_ab98a8babb274834938370cd69f4bc4f(eventobject) {
    var ntf = new kony.mvc.Navigation("frmProperties");
    ntf.navigate();
}