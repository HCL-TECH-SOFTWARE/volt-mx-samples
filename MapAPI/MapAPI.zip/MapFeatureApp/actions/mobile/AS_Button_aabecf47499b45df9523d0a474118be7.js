function AS_Button_aabecf47499b45df9523d0a474118be7(eventobject) {
    var ntf = new kony.mvc.Navigation("frmProperties");
    ntf.navigate();
}