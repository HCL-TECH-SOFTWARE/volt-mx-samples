function AS_Button_dd79bde8f08846709864af71f674fa8f(eventobject) {
    var ntf = new kony.mvc.Navigation("frmProperties");
    ntf.navigate();
}