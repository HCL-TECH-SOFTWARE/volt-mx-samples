function AS_Button_a240aaa04ba447688597579b4055ea57(eventobject) {
    var ntf = new kony.mvc.Navigation("frmProperties");
    ntf.navigate();
}