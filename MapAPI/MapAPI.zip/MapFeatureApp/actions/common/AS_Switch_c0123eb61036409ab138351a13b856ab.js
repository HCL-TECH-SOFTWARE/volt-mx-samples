function AS_Switch_c0123eb61036409ab138351a13b856ab(eventobject) {
    var self = this;
    return self.autoCenterOnOff.call(this);
}