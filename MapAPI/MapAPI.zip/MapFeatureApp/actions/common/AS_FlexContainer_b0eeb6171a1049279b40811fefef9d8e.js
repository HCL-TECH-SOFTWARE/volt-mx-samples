function AS_FlexContainer_b0eeb6171a1049279b40811fefef9d8e(eventobject, x, y) {
    var self = this;
    this.animateFlexToSmall();
}