function AS_Switch_bb7a95a2770c478ca64c779efb5dd967(eventobject) {
    var self = this;
    return self.autoCenterOnOff.call(this);
}