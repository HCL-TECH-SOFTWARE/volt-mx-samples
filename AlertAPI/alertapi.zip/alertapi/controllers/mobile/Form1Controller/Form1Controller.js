define({ 


 confirmationAlert: function(){ 
   //Creating the basicConfig object 
  var basicConf = {
    message: "This is an confirmation alert",
    alertType: constants.ALERT_TYPE_CONFIRMATION,
    
};
   //Creating the pspConfig object
  var pspConfig = {
    "contentAlignment": constants.ALERT_CONTENT_ALIGN_CENTER
};
   kony.ui.Alert(basicConf, pspConfig);
 },
  
   informationAlert: function(){ 
     //Creating the basicConfig object
  var basicConf = {
    message: "This is an info alert",
    alertType: constants.ALERT_TYPE_INFO,
 
};
     //Creating the pspConfig object
  var pspConfig = {
  "contentAlignment": constants.ALERT_CONTENT_ALIGN_LEFT
};
   kony.ui.Alert(basicConf, pspConfig);
 },
  
   errorAlert: function(){ 
   //Creating the basicConfig object
  var basicConf = {
    message: "This is an error alert",
    alertType: constants.ALERT_TYPE_ERROR,
   
};
     //Creating the pspConfig object
  var pspConfig = {
  "contentAlignment": constants.ALERT_CONTENT_ALIGN_RIGHT
};
   kony.ui.Alert(basicConf, pspConfig);
 },
 });