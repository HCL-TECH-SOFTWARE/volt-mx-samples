define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnConfirmation **/
    AS_Button_d56118068ce24deeab5a1878718ca769: function AS_Button_d56118068ce24deeab5a1878718ca769(eventobject) {
        var self = this;
        return self.confirmationAlert.call(this);
    },
    /** onClick defined for btnError **/
    AS_Button_fcbefea08e0d4a229d5880ccd9880991: function AS_Button_fcbefea08e0d4a229d5880ccd9880991(eventobject) {
        var self = this;
        return self.errorAlert.call(this);
    },
    /** onClick defined for btnInformation **/
    AS_Button_e94edc39b8b549a997fd8117688feb4c: function AS_Button_e94edc39b8b549a997fd8117688feb4c(eventobject) {
        var self = this;
        return self.informationAlert.call(this);
    }
});