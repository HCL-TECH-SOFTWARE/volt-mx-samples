ALTER TABLE `student_data`
	CHANGE `department_id` `departmentId` VARCHAR(40),
	DROP COLUMN `department`,
	DROP COLUMN `year`;
