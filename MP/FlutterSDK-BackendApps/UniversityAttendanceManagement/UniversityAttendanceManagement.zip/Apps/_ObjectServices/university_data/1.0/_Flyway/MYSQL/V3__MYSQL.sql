ALTER TABLE `student_data`
	ADD `year` VARCHAR(40);
