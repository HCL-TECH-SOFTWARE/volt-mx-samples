ALTER TABLE `student_data`
	ADD `department_id` BIGINT;
