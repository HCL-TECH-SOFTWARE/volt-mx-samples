ALTER TABLE `attendance_data`
	CHANGE `date` `attendanceDate` VARCHAR(40),
	CHANGE `department_name` `departmentId` VARCHAR(40),
	CHANGE `didPresent` `isPresent` BOOLEAN,
	CHANGE `student_name` `studentId` VARCHAR(40);
