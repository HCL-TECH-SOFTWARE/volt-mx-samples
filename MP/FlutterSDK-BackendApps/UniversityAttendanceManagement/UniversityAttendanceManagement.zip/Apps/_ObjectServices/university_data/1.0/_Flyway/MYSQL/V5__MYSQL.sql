RENAME TABLE `departmentdata` TO `department_data`;
