RENAME TABLE `department_data` TO `departmentdata`;
