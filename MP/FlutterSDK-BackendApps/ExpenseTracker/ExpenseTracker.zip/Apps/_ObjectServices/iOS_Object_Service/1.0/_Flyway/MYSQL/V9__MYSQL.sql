ALTER TABLE `Object1`
	ADD `state` VARCHAR(40);
