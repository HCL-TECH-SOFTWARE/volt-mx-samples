ALTER TABLE `Object1`
	ADD `address` VARCHAR(40);
