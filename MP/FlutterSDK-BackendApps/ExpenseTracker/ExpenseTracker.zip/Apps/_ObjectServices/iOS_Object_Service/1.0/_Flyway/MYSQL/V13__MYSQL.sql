ALTER TABLE `transactions`
	ADD `day` BIGINT,
	ADD `month` BIGINT,
	ADD `year` BIGINT;
