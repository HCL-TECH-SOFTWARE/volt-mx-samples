ALTER TABLE `Object1`
	ADD `salary` VARCHAR(40);
