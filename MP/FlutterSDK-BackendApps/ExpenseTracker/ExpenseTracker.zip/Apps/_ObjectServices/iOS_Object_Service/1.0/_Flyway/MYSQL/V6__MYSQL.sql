ALTER TABLE `Object1`
	ADD `pincode` VARCHAR(40);
