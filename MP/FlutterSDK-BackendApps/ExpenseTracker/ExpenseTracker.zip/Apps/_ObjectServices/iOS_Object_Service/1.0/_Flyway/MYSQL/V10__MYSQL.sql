CREATE TABLE `transactions`(
	`account` VARCHAR(40),
	`amount` BIGINT,
	`category` VARCHAR(40),
	`CreatedBy` VARCHAR(32),
	`CreatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
	`date` VARCHAR(40),
	`id` BIGINT NOT NULL,
	`LastUpdatedBy` VARCHAR(32),
	`LastUpdatedDateTime` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
	`name` VARCHAR(40),
	`SoftDeleteFlag` BOOLEAN,
	`subcategory` VARCHAR(40),
	`type` VARCHAR(40),
	PRIMARY KEY(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `transactions`
	ADD CONSTRAINT `e50c884c6e268eb33c6289cedfb2c8` UNIQUE KEY(`id`);
