// index.js - Lambda Function Code
const Alexa = require('ask-sdk-core');
const axios = require('axios');

// In-memory storage (use DynamoDB in production)
let userData = {
    tasks: [],
    reminders: [],
    preferences: {},
    lookupData: {
    contacts: {
        "mom": "555-0123",
        "dad": "555-0124",
        "alice": "555-0456",
        "boss": "555-0789",
        "emergency": "911",
        "doctor": "555-1001"
    },
    facts: {
        "birthday": "Your birthday is October 10th",
        "anniversary": "Your anniversary is April 25th",
        "wifi password": "The Wi-Fi password is CoffeeShop2024!",
        "car insurance": "Your car insurance expires on December 1st, 2025",
        "favorite food": "Your favorite food is spicy ramen",
        "pet name": "Your dog's name is Bruno",
        "gym membership": "Your gym membership renews every 3 months"
    }
}

};

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    handle(handlerInput) {
        const speakOutput = 'Welcome to your Personal Assistant! I can help you with tasks, reminders, weather updates, and quick lookups. What would you like to do?';
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt('You can say things like add a task, set a reminder, what is the weather, or look up a phone number')
            .getResponse();
    }
};

// 1. Single Data Lookups
// Fixed DataLookupIntentHandler with better logic
const DataLookupIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'DataLookupIntent';
    },
    handle(handlerInput) {
        const slots = handlerInput.requestEnvelope.request.intent.slots;
        
        let lookupType = null;
        let lookupItem = null;
        
        // Get lookup type
        if (slots.lookupType && slots.lookupType.value) {
            lookupType = slots.lookupType.value.toLowerCase();
        }
        
        // Get lookup item
        if (slots.lookupItem && slots.lookupItem.value) {
            lookupItem = slots.lookupItem.value.toLowerCase();
        }
        
        console.log(`Lookup Type: ${lookupType}, Lookup Item: ${lookupItem}`);
        
        let speakOutput = '';
        
        // Handle phone number lookups
        if (lookupType === 'phone number' || lookupType === 'number' || lookupType === 'phone') {
            if (lookupItem && userData.lookupData.contacts[lookupItem]) {
                const phoneNumber = userData.lookupData.contacts[lookupItem];
                speakOutput = `The phone number for ${lookupItem} is ${phoneNumber}`;
            } else if (lookupItem) {
                speakOutput = `I don't have a phone number for ${lookupItem}`;
            } else {
                speakOutput = `Who's phone number would you like to look up?`;
            }
        }
        // Handle fact lookups
        else if (lookupType === 'fact' || lookupType === 'information' || lookupType === 'birthday' || lookupType === 'anniversary') {
            // For specific fact types, use the lookupType as the key
            let factKey = lookupType === 'fact' || lookupType === 'information' ? lookupItem : lookupType;
            
            if (factKey && userData.lookupData.facts[factKey]) {
                const fact = userData.lookupData.facts[factKey];
                speakOutput = fact;
            } else if (factKey) {
                speakOutput = `I don't have that information stored`;
            } else {
                speakOutput = `What information would you like to look up?`;
            }
        }
        // Handle cases where no lookup type is specified but we have an item
        else if (lookupItem) {
            // Try to find in contacts first
            if (userData.lookupData.contacts[lookupItem]) {
                const phoneNumber = userData.lookupData.contacts[lookupItem];
                speakOutput = `The phone number for ${lookupItem} is ${phoneNumber}`;
            }
            // Try to find in facts
            else if (userData.lookupData.facts[lookupItem]) {
                const fact = userData.lookupData.facts[lookupItem];
                speakOutput = fact;
            }
            else {
                speakOutput = `I don't have any information for ${lookupItem}`;
            }
        }
        // No clear lookup type or item
        else {
            speakOutput = `I can look up phone numbers and personal facts. Try saying "what's mom's phone number" or "when is my birthday"`;
        }
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};;

// 2. Task Management
const AddTaskIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AddTaskIntent';
    },
    handle(handlerInput) {
        const slots = handlerInput.requestEnvelope.request.intent.slots;
        
        let taskName;
        if (slots.taskName && slots.taskName.value) {
            taskName = slots.taskName.value;
        } else {
            taskName = null;
        }
        
        if (taskName) {
            const task = {
                id: Date.now(),
                name: taskName,
                completed: false,
                createdAt: new Date().toISOString()
            };
            userData.tasks.push(task);
            
            return handlerInput.responseBuilder
                .speak(`I've added "${taskName}" to your task list`)
                .getResponse();
        }
        
        return handlerInput.responseBuilder
            .speak('What task would you like to add?')
            .reprompt('Tell me the task you want to add')
            .getResponse();
    }
};

const ListTasksIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'ListTasksIntent';
    },
    handle(handlerInput) {
        const incompleteTasks = userData.tasks.filter(task => !task.completed);
        
        if (incompleteTasks.length === 0) {
            return handlerInput.responseBuilder
                .speak('You have no pending tasks. Great job!')
                .getResponse();
        }
        
        let speakOutput = `You have ${incompleteTasks.length} pending task${incompleteTasks.length > 1 ? 's' : ''}: `;
        incompleteTasks.forEach((task, index) => {
            speakOutput += `${index + 1}. ${task.name}${index < incompleteTasks.length - 1 ? ', ' : ''}`;
        });
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};

const CompleteTaskIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'CompleteTaskIntent';
    },
    handle(handlerInput) {
        const slots = handlerInput.requestEnvelope.request.intent.slots;
        
        let taskName;
        if (slots.taskName && slots.taskName.value) {
            taskName = slots.taskName.value.toLowerCase();
        } else {
            taskName = null;
        }
        
        const taskIndex = userData.tasks.findIndex(task => 
            task.name.toLowerCase().includes(taskName) && !task.completed
        );
        
        if (taskIndex !== -1) {
            userData.tasks[taskIndex].completed = true;
            userData.tasks[taskIndex].completedAt = new Date().toISOString();
            
            return handlerInput.responseBuilder
                .speak(`Great! I've marked "${userData.tasks[taskIndex].name}" as completed`)
                .getResponse();
        }
        
        return handlerInput.responseBuilder
            .speak(`I couldn't find a pending task matching "${taskName}"`)
            .getResponse();
    }
};

// 3. Reminders & Scheduling
const SetReminderIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SetReminderIntent';
    },
    handle(handlerInput) {
        const slots = handlerInput.requestEnvelope.request.intent.slots;
        
        let reminderText;
        if (slots.reminderText && slots.reminderText.value) {
            reminderText = slots.reminderText.value;
        } else {
            reminderText = null;
        }
        
        let reminderTime;
        if (slots.reminderTime && slots.reminderTime.value) {
            reminderTime = slots.reminderTime.value;
        } else {
            reminderTime = 'not specified';
        }
        
        let reminderDate;
        if (slots.reminderDate && slots.reminderDate.value) {
            reminderDate = slots.reminderDate.value;
        } else {
            reminderDate = 'today';
        }
        
        if (reminderText) {
            const reminder = {
                id: Date.now(),
                text: reminderText,
                time: reminderTime,
                date: reminderDate,
                createdAt: new Date().toISOString()
            };
            userData.reminders.push(reminder);
            
            let speakOutput = `I've set a reminder for "${reminderText}"`;
            if (reminderTime !== 'not specified') speakOutput += ` at ${reminderTime}`;
            if (reminderDate !== 'today') speakOutput += ` on ${reminderDate}`;
            
            return handlerInput.responseBuilder
                .speak(speakOutput)
                .getResponse();
        }
        
        return handlerInput.responseBuilder
            .speak('What would you like me to remind you about?')
            .reprompt('Tell me what you want to be reminded of')
            .getResponse();
    }
};

const ListRemindersIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'ListRemindersIntent';
    },
    handle(handlerInput) {
        if (userData.reminders.length === 0) {
            return handlerInput.responseBuilder
                .speak('You have no reminders set')
                .getResponse();
        }
        
        let speakOutput = `You have ${userData.reminders.length} reminder${userData.reminders.length > 1 ? 's' : ''}: `;
        userData.reminders.forEach((reminder, index) => {
            speakOutput += `${index + 1}. ${reminder.text}`;
            if (reminder.time !== 'not specified') speakOutput += ` at ${reminder.time}`;
            if (reminder.date !== 'today') speakOutput += ` on ${reminder.date}`;
            speakOutput += index < userData.reminders.length - 1 ? ', ' : '';
        });
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};

// 4. Weather/Time-Based Alerts
const WeatherIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'WeatherIntent';
    },
    async handle(handlerInput) {
        const slots = handlerInput.requestEnvelope.request.intent.slots;
        
        let location;
        if (slots.location && slots.location.value) {
            location = slots.location.value;
        } else {
            location = 'your location';
        }
        
        // Simulated weather data (in production, use actual weather API)
        const weatherData = {
            temperature: Math.floor(Math.random() * 30) + 10,
            condition: ['sunny', 'cloudy', 'rainy', 'partly cloudy'][Math.floor(Math.random() * 4)],
            humidity: Math.floor(Math.random() * 50) + 30
        };
        
        const speakOutput = `The current weather in ${location} is ${weatherData.temperature} degrees and ${weatherData.condition}, with ${weatherData.humidity}% humidity`;
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};

const TimeIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'TimeIntent';
    },
    handle(handlerInput) {
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', {
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        const speakOutput = `The current time is ${timeString}`;
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};

// Help Handler
const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'I am your personal assistant! I can help you with managing tasks, setting reminders, weather and time updates, and quick lookups. What would you like to try?';
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt('What would you like to do?')
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'Goodbye! Have a great day!';
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};

const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'Sorry, I did not understand that. I can help with tasks, reminders, weather, and quick lookups. What would you like to do?';
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt('Try saying help to hear what I can do')
            .getResponse();
    }
};

const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        return handlerInput.responseBuilder.getResponse();
    }
};

const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const speakOutput = 'Sorry, I had trouble doing what you asked. Please try again.';
        console.log(`~~~~ Error handled: ${JSON.stringify(error)}`);
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        DataLookupIntentHandler,
        AddTaskIntentHandler,
        ListTasksIntentHandler,
        CompleteTaskIntentHandler,
        SetReminderIntentHandler,
        ListRemindersIntentHandler,
        WeatherIntentHandler,
        TimeIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler
    )
    .addErrorHandlers(ErrorHandler)
    .withCustomUserAgent('personal-assistant/v1.0')
    .lambda();