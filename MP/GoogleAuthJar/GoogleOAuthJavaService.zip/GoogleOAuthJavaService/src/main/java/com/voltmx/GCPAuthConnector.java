package com.voltmx;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.AccessToken;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.auth.ServiceAccountSigner;

import com.hcl.voltmx.middleware.api.ConfigurableParametersHelper;
import com.hcl.voltmx.middleware.api.ServicesManager;
import com.hcl.voltmx.middleware.common.JavaService2;
import com.hcl.voltmx.middleware.controller.DataControllerRequest;
import com.hcl.voltmx.middleware.controller.DataControllerResponse;
import com.hcl.voltmx.middleware.dataobject.Param;
import com.hcl.voltmx.middleware.dataobject.Result;

import java.nio.charset.StandardCharsets;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Collections;

/**
 * GCP Authentication Connector for VoltMX Foundry
 * Uses Google Auth Library to obtain a Bearer token from service account credentials.
 */
public class GCPAuthConnector implements JavaService2 {

    private static final String DEFAULT_SCOPE = "https://www.googleapis.com/auth/cloud-platform";
    private static final String GCP_SA_KEY_PROPERTY = "GCP_SA_KEY";

        /**
         * Invokes the GCP authentication logic.
         * Retrieves service account JSON from configuration, obtains an access token,
         * and returns the result in Volt MX Foundry format.
         *
         * @param methodID The method identifier (not used in this implementation).
         * @param inputArray Optional input parameters (first element can be custom OAuth scope).
         * @param request The DataControllerRequest from Volt MX Foundry.
         * @param response The DataControllerResponse from Volt MX Foundry.
         * @return Result object containing the access token or error details.
         * @throws Exception if any error occurs during authentication.
         */
    @Override
    public Object invoke(String methodID, Object[] inputArray, DataControllerRequest request, DataControllerResponse response) throws Exception {
        try {
            // Get service account JSON from Foundry configuration
            String serviceAccountJson = getServiceAccountJsonFromConfig(request);

            if (serviceAccountJson == null || serviceAccountJson.trim().isEmpty()) {
                return createErrorResult("Service account JSON not found in configuration. Please configure GCP_SA_KEY in Server Properties.");
            }

            // Allow custom scope from input parameters if provided
            String scope = DEFAULT_SCOPE;
            if (inputArray != null && inputArray.length > 0 && inputArray[0] instanceof String) {
                String customScope = (String) inputArray[0];
                if (customScope != null && !customScope.trim().isEmpty()) {
                    scope = customScope.trim();
                }
            }

            // Load credentials from JSON string
            GoogleCredentials credentials = ServiceAccountCredentials
                    .fromStream(new ByteArrayInputStream(serviceAccountJson.getBytes(StandardCharsets.UTF_8)))
                    .createScoped(Collections.singleton(scope));

            // Refresh and get access token
            credentials.refreshIfExpired();
            AccessToken token = credentials.getAccessToken();

            if (token != null && token.getTokenValue() != null && !token.getTokenValue().trim().isEmpty()) {
                return createSuccessResult(token.getTokenValue());
            } else {
                return createErrorResult("Failed to obtain access token from GCP");
            }

        } catch (IOException e) {
            System.err.println("Error loading service account credentials: " + e.getMessage());
            return createErrorResult("Error loading service account credentials: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("GCP Authentication Error: " + e.getMessage());
            return createErrorResult("Error in GCP authentication: " + e.getMessage());
        }
    }

    /**
     * Retrieves the GCP service account JSON string from Volt MX Foundry server properties.
     *
     * @param request The DataControllerRequest containing configuration access.
     * @return The service account JSON string, or null if not found or error occurs.
     */
    private String getServiceAccountJsonFromConfig(DataControllerRequest request) {
        try {
            if (request instanceof DataControllerRequest) {
                DataControllerRequest dataRequest = (DataControllerRequest) request;
                ServicesManager sm = dataRequest.getServicesManager();

                if (sm != null) {
                    ConfigurableParametersHelper paramHelper = sm.getConfigurableParametersHelper();

                    if (paramHelper != null) {
                        String serviceAccountJson = paramHelper.getServerProperty(GCP_SA_KEY_PROPERTY);
                        if (serviceAccountJson != null && !serviceAccountJson.trim().isEmpty()) {
                            return serviceAccountJson;
                        }
                    }
                }
            }
            return null;

        } catch (Exception e) {
            System.err.println("Error retrieving service account JSON from configuration: " + e.getMessage());
            return null;
        }
    }

    /**
     * Creates a Result object representing successful authentication.
     * Includes the access token, success status, and timestamp.
     *
     * @param accessToken The OAuth2 access token from GCP.
     * @return Result object with success parameters.
     */
    private Result createSuccessResult(String accessToken) {
        Result result = new Result();
        Param authParam = new Param("Authorization", "Bearer " + accessToken);
        Param statusParam = new Param("auth_success", "true", "string");
        Param timestampParam = new Param("auth_timestamp", String.valueOf(System.currentTimeMillis()), "string");
        result.addParam(authParam);
        result.addParam(statusParam);
        result.addParam(timestampParam);
        return result;
    }

    /**
     * Creates a Result object representing an authentication error.
     * Includes the error message, failure status, and timestamp.
     *
     * @param errorMessage The error message to include in the result.
     * @return Result object with error parameters.
     */
    private Result createErrorResult(String errorMessage) {
        Result result = new Result();
        Param errorParam = new Param("error", errorMessage, "string");
        Param statusParam = new Param("auth_success", "false", "string");
        Param timestampParam = new Param("error_timestamp", String.valueOf(System.currentTimeMillis()), "string");
        result.addParam(errorParam);
        result.addParam(statusParam);
        result.addParam(timestampParam);
        System.err.println("GCP Auth Error: " + errorMessage);
        return result;
    }
}