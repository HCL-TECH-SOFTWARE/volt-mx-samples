/*
#
#  Voltmx Inc.
#  Sample Command Handler @ Voltmx Foundry
#  Handling NLP response
#
*/
 
/*
 *  Pre-req
 *  Package Name: com.voltmx.botfm.onresponse
 *  Class Name: ResponseHandler
 *  Method Name: onResponse
 *  Method signature: public String onResponse(HashMap<String, String> responseFromNLP)
 *  Method Return Type: String
 * 
 */

package com.voltmx.botfm.onresponse;

import java.util.HashMap;

import com.voltmx.botfm.thirdparty.json.*;

public class ResponseHandler {
	
	/* Dialog States supported by Chatbot Framework
		1.	ELICITINTENT: Intent is not identified by NLP in the query
		2.	CONFIRMINTENT: Confirmation for the Intent that is identified by NLP
		3.	ELICITSLOT: Required Entity is missing for the Intent identified by NLP
		4.	FULFILLED: Command has been executed successfully
		5.	READYFORFULFILLMENT: Command is ready to be executed
		6.	FAILED: Conversation with the NLP failed

	*/
	public enum DialogState {
		ELICITINTENT,
		CONFIRMINTENT,
		ELICITSLOT,
		FULFILLED,
		READYFORFULFILLMENT,
		FAILED
	}

	public String onResponse(HashMap<String, String> responseFromNLP) {
		/*
		 * Sample structure of responseFromNLP
		 * {
				stringResponse={
         			"entities":{"KDxCbAccountType":["Savings"]},
         			"payload":{},
         			"intent":"KDxCbAccountBalance",
         			"queries":"[\"what is my savings account balance\"]",
         			"command":"AccountBalanceHandle"
				},
				dialogState=READYFORFULFILLMENT
			}		
		 */
		
		String dialogState = responseFromNLP.get("dialogState");
		String stringResponse = responseFromNLP.get("stringResponse");
		JSONObject response = new JSONObject(stringResponse);
		JSONObject responseJSON = new JSONObject();	
		
		// Command Handling based on the command provided in intent entity mapper
		switch(response.getString("command").toLowerCase()) {
			case  "accountbalancehandle":
				responseJSON = accountBalanceHandle(dialogState, response);
				break;
			case "showbill":
				responseJSON = showBillHandle(dialogState, response);
				break;
			case "payrent":
				responseJSON = payRentHandle(dialogState, response);
				break;
			case "nearestatm":
				responseJSON = nearestATMHandle(dialogState, response);
				break;
			case "cardlost":
				responseJSON = cardLostHandle(dialogState, response);
				break;
				
		}	
		// Return the response as a String
		return responseJSON.toString();
		
	}
	
	// Returns the account balance as a message type
	private JSONObject accountBalanceHandle(String dialogState, JSONObject response) {		 
		JSONObject res = new JSONObject();
		if(dialogState.equalsIgnoreCase(DialogState.READYFORFULFILLMENT.name())) {
			// Hit LOB and get the response
			// Sample way to send message response
			JSONObject payload = new JSONObject();
		    payload.put("message", "Your account balance is Rs. 5000 only");
		    payload.put("type", "message");
		    res.put("payload", payload);
//			res.put("message", "Your account balance is Rs. 5000 only");
//			res.put("type", "message");				
		}		
		return res;
	}
	
	// Returns the bills as a PDF
	private JSONObject showBillHandle(String dialogState, JSONObject response) {
		JSONObject responseJson = new JSONObject();
		if(dialogState.equalsIgnoreCase(DialogState.READYFORFULFILLMENT.name())) {
			// Hit LOB and get the response
			// Sample way to send PDF response
			JSONObject payload = new JSONObject();
		    payload.put("type","pdf");
		    payload.put("url", "https://www.greatlakeslink.com/mglstatic/borrower/fiq/pdf/sample_credit_card_statement_fiq.pdf");
		    payload.put("title", "CreditCard_Bill.pdf");
			responseJson.put("payload", payload);
		}
		return responseJson;
	}
	
	// Returns the response to pay rent
	private JSONObject payRentHandle(String dialogState, JSONObject response) {
		JSONObject responseJson = new JSONObject();
		if(dialogState.equalsIgnoreCase(DialogState.READYFORFULFILLMENT.name())) {
			// Hit LOB and get the response 
			// Sample way to send message response
			// DialogState = READYFORFULFILLMENT
			JSONObject payload = new JSONObject();
			payload.put("type","message");
			payload.put("message", "The amount has been transferred");
			responseJson.put("payload", payload);
		}
		else if(dialogState.equalsIgnoreCase(DialogState.CONFIRMINTENT.name())) {
			// Hit LOB and get the response 
			// Sample way to send message response
			// DialogState = CONFIRMINTENT
			JSONObject payload = new JSONObject();
			payload.put("type", "message");
			payload.put("message", "Let me confirm. I have the source account to be your Checking account, the target account to be 'Madrone Apartments' account and the amount to be $2000. Is this correct?");
			responseJson.put("payload", payload);
		}
		return responseJson;
	}
	
	// Returns the nearest ATM as a Location
	private JSONObject nearestATMHandle(String dialogState, JSONObject response) {
		JSONObject responseJson = new JSONObject();
		if(dialogState.equalsIgnoreCase(DialogState.READYFORFULFILLMENT.name())) {
			// Hit LOB and get the response 
			// Sample way to send Location response
			JSONObject payload = new JSONObject();
			payload.put("type","location");
			payload.put("latitude","42.2803616");
			payload.put("longitude","-83.7482194");
			payload.put("title","ATM Location");
			payload.put("details", "The closest American ATM to you is located on 201 S Main st., Ann Arbor, Mi 48104, United States.");
			responseJson.put("payload", payload);
		}		
		return responseJson;
	}
	
	// Returns the Lost card response as a hyperlink
	private JSONObject cardLostHandle(String dialogState, JSONObject response) {
		JSONObject responseJson = new JSONObject();
		if(dialogState.equalsIgnoreCase(DialogState.READYFORFULFILLMENT.name())) {
			// Hit LOB and get the response 
			// Sample way to send Hyperlink response
			JSONObject payload = new JSONObject();
			payload.put("type","hyperlink");
			payload.put("url","https://en.wikipedia.org/wiki/Main_Page");
			responseJson.put("payload", payload);
		}		
		return responseJson;
	}

}
