define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnConvert **/
    AS_Button_eee4486a27c0467ea2abf390bc7b2dbf: function AS_Button_eee4486a27c0467ea2abf390bc7b2dbf(eventobject) {
        var self = this;
        return self.onclickfloor.call(this);
    },
    /** onClick defined for btnSqrt **/
    AS_Button_e4fa4c6d5caa416181762baf81e61855: function AS_Button_e4fa4c6d5caa416181762baf81e61855(eventobject) {
        var self = this;
        return self.onclicksqrt.call(this);
    },
    /** onClick defined for btnMax **/
    AS_Button_db19988397a345df8760bf6497bc95df: function AS_Button_db19988397a345df8760bf6497bc95df(eventobject) {
        var self = this;
        return self.onclickmax.call(this);
    },
    /** onClick defined for CopybtnMax0j6291b3e84b944 **/
    AS_Button_f530d2ece6f0441e96b8477454da034d: function AS_Button_f530d2ece6f0441e96b8477454da034d(eventobject) {
        var self = this;
        return self.onclickRandom.call(this);
    },
    /** onClick defined for btnMin **/
    AS_Button_e07d9f115c4b4fe793209323efa35267: function AS_Button_e07d9f115c4b4fe793209323efa35267(eventobject) {
        var self = this;
        return self.onclickmin.call(this);
    },
    /** onClick defined for CopybtnMin0gacb1957984146 **/
    AS_Button_jba803cc599840ec9272cb2fbd2222be: function AS_Button_jba803cc599840ec9272cb2fbd2222be(eventobject) {
        var self = this;
        return self.onclickpi.call(this);
    },
    /** onClick defined for btnSquare **/
    AS_Button_hd9f281aa59646168b486e798223be76: function AS_Button_hd9f281aa59646168b486e798223be76(eventobject) {
        var self = this;
        return self.onclickpow.call(this);
    }
});