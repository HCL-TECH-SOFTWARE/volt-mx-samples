define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0g2050c4484f342 **/
    AS_Button_d4814c58550a408dbfd241a621c8297c: function AS_Button_d4814c58550a408dbfd241a621c8297c(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmMedia");
        ntf.navigate();
    },
    /** onClick defined for CopyButton0afb30ec0b39d48 **/
    AS_Button_d5199d5abd6543c7b9ba9ac080ef7014: function AS_Button_d5199d5abd6543c7b9ba9ac080ef7014(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmRecord");
        ntf.navigate();
    }
});