define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0e2ba68747a194a **/
    AS_Button_d8649be3fb9943eca24f1dc0ec312518: function AS_Button_d8649be3fb9943eca24f1dc0ec312518(eventobject) {
        var self = this;
        return self.Record.call(this);
    },
    /** onClick defined for Button0cb844f294f9240 **/
    AS_Button_dea673d2f11e4f5ea9b6c06dbb97978d: function AS_Button_dea673d2f11e4f5ea9b6c06dbb97978d(eventobject) {
        var self = this;
        return self.StartRecording.call(this);
    },
    /** onClick defined for Button0adf39dcb924541 **/
    AS_Button_f899717fc5d341988d8b22e0b748ff85: function AS_Button_f899717fc5d341988d8b22e0b748ff85(eventobject) {
        var self = this;
        return self.StopRecording.call(this);
    },
    /** onClick defined for btnPlay **/
    AS_Button_d952c9407f37483fb259b8b3d0e11b4d: function AS_Button_d952c9407f37483fb259b8b3d0e11b4d(eventobject) {
        var self = this;
        this.view.pauseRecord.setVisibility(true);
        this.view.btnPlay.setVisibility(false);
        self.playrecordedfile.call(this);
    },
    /** onClick defined for btnStop **/
    AS_Button_c9c36d5019934bc5a049ef591d721de7: function AS_Button_c9c36d5019934bc5a049ef591d721de7(eventobject) {
        var self = this;
        this.view.pauseRecord.setVisibility(false);
        this.view.btnPlay.setVisibility(true);
        self.stoprecordedfile.call(this);
    },
    /** onTouchStart defined for pauseRecord **/
    AS_Label_fe525ec07ee04ad69e95fd77ff340b4b: function AS_Label_fe525ec07ee04ad69e95fd77ff340b4b(eventobject, x, y) {
        var self = this;
        this.view.pauseRecord.setVisibility(false);
        this.view.btnPlay.setVisibility(true);
        self.pauserecordedfile.call(this);
    },
    /** onClick defined for headerButtonLeft **/
    AS_Button_d44c2f1921c54bb1812d63999edc68b6: function AS_Button_d44c2f1921c54bb1812d63999edc68b6(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmHome");
        ntf.navigate();
    }
});