define({ 
  recordplayer: null,
  recorderSuccessfullyReturnedSavedPath: null,
  testSavedRecordedFileMediaObj: null,
  //Use the below function to create a record object.
  Record: function() {

    var destDirPath = kony.io.FileSystem.getExternalStorageDirectoryPath() + "/MediaRecorders";
    var destFilePath=destDirPath+"/redordedFile";
    var directory = new  kony.io.File(destDirPath);
    directory.createDirectory();
    var file = new kony.io.File(destFilePath);
    file.createFile();
    var config = {
      onSuccess: this.record_success_call,
      onFailure: this.record_error_call
    };
    recordplayer = kony.media.record(file, config);
  },

  record_error_call: function(errorMessage) {
    var errorMesg = "Reason for failure is : " + errorMessage;
    alert(errorMesg);
  },

  record_success_call: function(fp) {
    recorderSuccessfullyReturnedSavedPath=fp;
    alert("You have successfully created a record object and a file named " +fp.name); 
    testSavedRecordedFileMediaObj=kony.media.createFromFile(recorderSuccessfullyReturnedSavedPath);
  },
  //Use the startRecording() method to start your device to record your audio.
  StartRecording: function() {
    recordplayer.startRecording();
    alert("Recording has started");
  },
  //Use the stopRecording() method to stop your device from recording your audio
  StopRecording: function() {
    recordplayer.stopRecording();
    alert("Recording has stopped");
  },
  //Use the below function to play the recorded file 
  playrecordedfile: function()
  {
    testSavedRecordedFileMediaObj.play(1);
  },
  //Use the below function to stop the recorded file from playing
  stoprecordedfile: function()
  {
    testSavedRecordedFileMediaObj.stop();
  },
  //Use the below function to pause the recorded file.
  pauserecordedfile: function()
  {
    testSavedRecordedFileMediaObj.pause();
  }
});