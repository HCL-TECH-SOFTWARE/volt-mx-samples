define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for headerButtonLeft **/
    AS_Button_cb84f64325304fa8ae5c06f71beb8c56: function AS_Button_cb84f64325304fa8ae5c06f71beb8c56(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmHome");
        ntf.navigate();
    },
    /** onClick defined for Button0g2050c4484f342 **/
    AS_Button_b13bae579e8940788598abe38d258a55: function AS_Button_b13bae579e8940788598abe38d258a55(eventobject) {
        var self = this;
        return self.createMedia.call(this);
    },
    /** onClick defined for Button0c9ef5e96b2954c **/
    AS_Button_d49eb22689484325b7fce8cac59aff45: function AS_Button_d49eb22689484325b7fce8cac59aff45(eventobject) {
        var self = this;
        return self.createMediaFromURI.call(this);
    },
    /** onClick defined for btnPlay **/
    AS_Button_bc902b20c8464db097a6d4feb14673dc: function AS_Button_bc902b20c8464db097a6d4feb14673dc(eventobject) {
        var self = this;
        this.view.Pause.setVisibility(true);
        this.view.btnPlay.setVisibility(false);
        self.playMedia.call(this);
    },
    /** onTouchStart defined for Pause **/
    AS_Label_f4e6fc03b041463e87f008614bb0a336: function AS_Label_f4e6fc03b041463e87f008614bb0a336(eventobject, x, y) {
        var self = this;
        this.view.Pause.setVisibility(false);
        this.view.btnPlay.setVisibility(true);
        self.pauseMedia.call(this);
    },
    /** onClick defined for btnStop **/
    AS_Button_ge167f27582943e180ae2668ff9910f6: function AS_Button_ge167f27582943e180ae2668ff9910f6(eventobject) {
        var self = this;
        this.view.Pause.setVisibility(false);
        this.view.btnPlay.setVisibility(true);
        self.stopMedia.call(this);
    }
});