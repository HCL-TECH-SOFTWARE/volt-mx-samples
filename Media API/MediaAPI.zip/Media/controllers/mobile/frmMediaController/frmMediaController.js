define({ 

  mediaObj:null,
  /*Use the below function to create a media object from a file. We use the 
FileSystem and File APIs to access the media file present in the Visualizer 
project*/
  createMedia: function()
  {
    try{
     if(kony.os.deviceInfo().name === "iPhone")
  	  var destFilePath = kony.io.FileSystem.getDataDirectoryPath() + constants.FILE_PATH_SEPARATOR + "first.mp3";
  else if(kony.os.deviceInfo().name === "android")
      var destFilePath = kony.io.FileSystem.getDataDirectoryPath() + "first.mp3";  
    kony.io.FileSystem.copyBundledRawFileTo("first.mp3", destFilePath);  
    var file = new kony.io.File(destFilePath);
    mediaObj = kony.media.createFromFile(file);
    alert("You have successfully created a media object");
  }
    catch(e)
      {
        alert("Error" +e);
      }
  },
  //Use the play() method to start playing the media object
  playMedia: function()
  {
  mediaObj.play();
},
  //Use the pause() method to pause the media object from playing
  pauseMedia: function()
  {
  mediaObj.pause();
},
  //Use the stop() method to stop the media object from playing
  stopMedia:function()
  {
    mediaObj.stop();
  },
  //Use the below function to create a media object from URI. 
  createMediaFromURI: function()
  {
    try{
  mediaObj = kony.media.createFromUri("http://www.largesound.com/ashborytour/sound/brobob.mp3");
  alert("You have successfully accessed Media from a URL");  
    }
    catch(e)
      {
        alert("Error " +e);
      }
    }
 });