// function failureCallback(errorMessage) {
//   var errorMesg = "Reason for failure is : " + errorMessage;
//   alert(errorMesg);
// }

// function successCallback(fileobj) {
//   alert("Success");

// }

// var recordObj = {};
// function record()
// {
//   try{
//     var config = {
//       onSuccess: successCallback,
//       onFailure: failureCallback
//     };
//     var mainLoc = kony.io.FileSystem.getDatabaseDirectoryPath();
//    var fileObj =  new kony.io.File(mainLoc+"/Recording");
//    // fileObj.createFile("Recording");
//     recordObj = kony.media.record(fileObj,config);
//     alert("You have successfully created a record object");
//   }
//   catch(e)
//   {
//     alert("Error"+e);
//   }
// }

// function startRecord()
// {
//   try{
//     recordObj.startRecording();
//     alert("Recording has started");  
//   }
//   catch(e)
//   {
//     alert("Error"+e);
//   }
// }

// function stopRecord()
// {
//   try{
//     recordObj.stopRecording();
//     alert("Recording has ended");  
//   }
//   catch(e)
//   {
//     alert("Error"+e);
//   }
// }