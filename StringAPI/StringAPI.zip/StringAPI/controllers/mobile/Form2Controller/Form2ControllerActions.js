define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnASCII **/
    AS_Button_b87b7a1cd8c14ecdb10a82cf7a6140bf: function AS_Button_b87b7a1cd8c14ecdb10a82cf7a6140bf(eventobject) {
        var self = this;
        return self.isAsciiAlpha.call(this);
    },
    /** onClick defined for btnASCIIAlphanumeric **/
    AS_Button_j96848ba6f3742e192b17a1eae38036c: function AS_Button_j96848ba6f3742e192b17a1eae38036c(eventobject) {
        var self = this;
        return self.isAsciiAlphaNumeric.call(this);
    },
    /** onClick defined for btnEmail **/
    AS_Button_abea1d1ea118458b9a2769ff59174d4d: function AS_Button_abea1d1ea118458b9a2769ff59174d4d(eventobject) {
        var self = this;
        return self.isValidEmail.call(this);
    },
    /** onClick defined for btnConcatenate **/
    AS_Button_bc9bc7ed509b45bca7e8b2c17b7be86e: function AS_Button_bc9bc7ed509b45bca7e8b2c17b7be86e(eventobject) {
        var self = this;
        return self.rep.call(this);
    },
    /** onClick defined for btnReverse **/
    AS_Button_b10bd2e992cc4199adecc073e7c5fb84: function AS_Button_b10bd2e992cc4199adecc073e7c5fb84(eventobject) {
        var self = this;
        return self.reverse.call(this);
    },
    /** onClick defined for btnTrim **/
    AS_Button_e9b0813f5ded49e29eb0c31bd2d45c8b: function AS_Button_e9b0813f5ded49e29eb0c31bd2d45c8b(eventobject) {
        var self = this;
        return self.trim.call(this);
    },
    /** onClick defined for btnBack **/
    AS_Button_c9fa59e43a3e4eee89c370a943669670: function AS_Button_c9fa59e43a3e4eee89c370a943669670(eventobject) {
        var self = this;
        self.trim.call(this);
        var ntf = new kony.mvc.Navigation("Form1");
        ntf.navigate();
    },
    /** onClick defined for CopybtnASCIIAlphanumeric0a841e363f73848 **/
    AS_Button_gc36fee38d314b7a99ae6a79294c9124: function AS_Button_gc36fee38d314b7a99ae6a79294c9124(eventobject) {
        var self = this;
        return self.isNumeric.call(this);
    }
});