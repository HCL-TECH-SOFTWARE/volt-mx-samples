@protocol NSObjectInstanceExports;
@protocol NSObjectClassExports;
@protocol NSObjectInstanceExports_;
@protocol NSObjectClassExports_;
