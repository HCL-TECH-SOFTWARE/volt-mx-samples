define({ 
  //Use the below function to save sensitive data  to your device keychain
  save: function(){ 
    var cred = {
      "securedata": JSON.stringify(this.view.tbxData.text),
      "secureaccount": "John",
      "identifier": "Apple",
    };
    kony.keychain.save(cred);
    alert("The details are successfully stored");
  },
  //Use the below function to retrieve sensitive data from your device keychain   
  retrieve: function(){
    var cred = {
      "identifier": "Apple"
    };
    var credDetails= kony.keychain.retrieve(cred);
    alert("The details retreived are " +JSON.stringify(credDetails));   
  },
  //Use the below function to remove sensitive data from your device keychain
  remove: function(){  
    var cred = {
      "identifier": "Apple"
    };
    kony.keychain.remove(cred);
    alert("The details are removed");
  }

});