define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnSave **/
    AS_Button_d0b4f1654622443eae80bc95496aface: function AS_Button_d0b4f1654622443eae80bc95496aface(eventobject) {
        var self = this;
        return self.save.call(this);
    },
    /** onClick defined for btnRetreive **/
    AS_Button_h0aa65b0b27540dc80c99ce25f001672: function AS_Button_h0aa65b0b27540dc80c99ce25f001672(eventobject) {
        var self = this;
        return self.retrieve.call(this);
    },
    /** onClick defined for btnRemove **/
    AS_Button_e4b5d71a0512417194f9bbe12d89a6b9: function AS_Button_e4b5d71a0512417194f9bbe12d89a6b9(eventobject) {
        var self = this;
        return self.remove.call(this);
    }
});