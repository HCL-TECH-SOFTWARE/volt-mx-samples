function p2kwiet140781533139_segHealthMenu_onRowClick_seq0(eventobject, sectionNumber, rowNumber) {
    return onRowClick_FrmHomeMenu.call(this, rowNumber);
}