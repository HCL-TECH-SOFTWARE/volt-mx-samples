function p2kwiet140781533147_button17218328914349_onClick_seq0(eventobject) {
    return saveVitaminsDetails.call(this);
}