function p2kwiet140781533107_characteristics_postshow_seq0(eventobject) {
    return initAuthCharacteristics.call(this);
}