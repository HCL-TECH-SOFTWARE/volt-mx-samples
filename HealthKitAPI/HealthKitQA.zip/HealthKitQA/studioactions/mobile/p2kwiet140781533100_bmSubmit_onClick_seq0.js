function p2kwiet140781533100_bmSubmit_onClick_seq0(eventobject) {
    return saveDetailsBody.call(this);
}