function p2kwiet140781533147_button17218328914391_onClick_seq0(eventobject) {
    return readNutritionDetails.call(this);
}