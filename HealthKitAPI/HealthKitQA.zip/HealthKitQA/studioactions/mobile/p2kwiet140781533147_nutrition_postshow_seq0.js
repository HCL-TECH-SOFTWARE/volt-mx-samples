function p2kwiet140781533147_nutrition_postshow_seq0(eventobject) {
    drawWidgets.call(this, nutritionObjs, nutrition.flNut, null);
    initNutritionAuth.call(this);
}