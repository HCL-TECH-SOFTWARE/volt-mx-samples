function p2kwiet140781533154_button17218328914391_onClick_seq0(eventobject) {
    return readResultsDetails.call(this);
}