function p2kwiet140781533139_frmHome_postshow_seq0(eventobject) {
    nutrition.destroy();
    results.destroy();
    vitalsigns.destroy();
    characteristics.destroy();
}