function p2kwiet140781533160_button17218328914391_onClick_seq0(eventobject) {
    return readVitalSignsDetails.call(this);
}