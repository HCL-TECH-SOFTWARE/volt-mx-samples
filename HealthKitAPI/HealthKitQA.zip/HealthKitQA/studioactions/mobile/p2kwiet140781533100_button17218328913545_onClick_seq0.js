function p2kwiet140781533100_button17218328913545_onClick_seq0(eventobject) {
    return readBodyDetails.call(this);
}