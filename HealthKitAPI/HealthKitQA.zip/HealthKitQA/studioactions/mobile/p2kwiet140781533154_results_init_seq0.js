function p2kwiet140781533154_results_init_seq0(eventobject) {
    results.btnDummyResults.opacity = 0;
}