function p2kwiet140781533154_results_postshow_seq0(eventobject) {
    drawWidgets.call(this, resultsObjs, results.flNut, null);
    initAuthResults.call(this);
}