function p2kwiet140781533134_button17218328913545_onClick_seq0(eventobject) {
    return readFitnessDetails.call(this);
}