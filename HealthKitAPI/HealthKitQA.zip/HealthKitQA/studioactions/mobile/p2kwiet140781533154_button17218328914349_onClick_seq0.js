function p2kwiet140781533154_button17218328914349_onClick_seq0(eventobject) {
    return saveDetailsResults.call(this);
}