function p2kwiet140781533100_body_postshow_seq0(eventobject) {
    return initAuthBody.call(this);
}