function p2kwiet140781533160_vitalsigns_postshow_seq0(eventobject) {
    drawWidgets.call(this, vitalSignsObjs, vitalsigns.flNut, null);
    initAuthVitalSigns.call(this);
}