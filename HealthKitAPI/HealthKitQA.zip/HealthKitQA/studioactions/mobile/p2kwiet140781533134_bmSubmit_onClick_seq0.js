function p2kwiet140781533134_bmSubmit_onClick_seq0(eventobject) {
    return saveFitnessDetails.call(this);
}