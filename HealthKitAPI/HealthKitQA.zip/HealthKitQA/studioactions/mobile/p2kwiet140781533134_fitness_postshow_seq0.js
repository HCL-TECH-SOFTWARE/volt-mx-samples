function p2kwiet140781533134_fitness_postshow_seq0(eventobject) {
    return initAuthFitness.call(this);
}