function p2kwiet140781533111_readCharacteristicsDetails_titlebarAction(eventobject) {
    return readCharacteristicsDetails.call(this);
}