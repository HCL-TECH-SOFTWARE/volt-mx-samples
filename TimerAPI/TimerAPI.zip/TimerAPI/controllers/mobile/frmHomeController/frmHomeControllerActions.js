define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnSchedule **/
    AS_Button_ja58bd334fd849888a4b32145c8917e3: function AS_Button_ja58bd334fd849888a4b32145c8917e3(eventobject) {
        var self = this;
        //To schedule a timer to display an alert after 3 seconds use the below snippet.
        kony.timer.schedule("timer4", this.generateAlert, 3, true);
    },
    /** onClick defined for btnSetCallBack **/
    AS_Button_cc8938cecffa4bcf91eaea8292768808: function AS_Button_cc8938cecffa4bcf91eaea8292768808(eventobject) {
        var self = this;
        //To set a callback function for a scheduled timer, use the below code snippet.
        kony.timer.setCallBack("timer4", this.callbackfunction);
    },
    /** onClick defined for btnCancel **/
    AS_Button_ae0def9e0e484d95ab6d80c1d8fbf154: function AS_Button_ae0def9e0e484d95ab6d80c1d8fbf154(eventobject) {
        var self = this;
        return self.cancelTimer.call(this);
    }
});