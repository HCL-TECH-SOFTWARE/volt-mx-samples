define({ 

  createUUID: function()
  {
    var uuid = kony.os.createUUID();
    alert("The created UUID is : " + uuid);
  },
  
  deviceInfo: function()
  {
    var deviceInfo= kony.os.deviceInfo();
    alert("The device info " + JSON.stringify(deviceInfo));
  },
  
  freeMemory: function()
  {
    var freeMemory = kony.os.freeMemory();
    alert("The Memory available is " +freeMemory);
  },
  
  getDeviceId: function()
  {
    var devId = kony.os.getDeviceId(0);
    alert("The Device Id of the sim slot is as follows "+devId);
  },
  
  getDeviceOrientation: function()
  {
    var orient=kony.os.getDeviceCurrentOrientation();
    if (orient == constants.DEVICE_ORIENTATION_PORTRAIT){
    alert("The device is in portrait mode" );
    }
    else
{
  alert("The device is in Landscape mode");
}
  },
  
 accelerometerSupport: function()
  {
    var accelerometer = kony.os.hasAccelerometerSupport();
    if(accelerometer === true)
      {
        alert("The device contains an Accelerometer sensor "); 
      }
    else
      alert("The device does not contain an Accelerometer sensor");      
    },
       
   cameraSupport: function()
  {
    var camera = kony.os.hasCameraSupport();
    if(camera === true)
      {
        alert("The device supports Camera "); 
      }
    else
      alert("The device does not support Camera ");      
    },
  
     gpsSupport: function()
  {
    var gps = kony.os.hasGPSSupport();
    if(gps === true)
      {
        alert("The device extends its support to GPS "); 
      }
    else
      alert("The device does not support GPS ");      
    },  
  
  orientationSupport: function()
  {
    var orientation = kony.os.hasOrientationSupport();
    if(orientation === true)
      {
        alert("The device supports orientation "); 
      }
    else
      alert("The device does not support orientation");      
    }, 

  hasTouchSupport: function(){
    var touch = kony.os.hasTouchSupport();
    if(touch === true)
      {
        alert("The device supports touch "); 
      }
    else
      alert("The device does not support touch");      
    }, 
  
  toCurrency: function()
  {
    value = this.view.tbx.text; 
    var currency = kony.os.toCurrency(value);
    alert(currency);
  },
  
    toNumber: function()
  {
    value = this.view.tbx.text; 
    var number = kony.os.toNumber(value);
    alert(number);
  },
  
  userAgent: function()
  {
  var devID = kony.os.userAgent();
  alert("User Agent return value is::" + devID);
}
 });