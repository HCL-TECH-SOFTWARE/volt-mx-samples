define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0bab0fd0f9ebf4d **/
    AS_Button_cb93c91aac534f59929a656e99438edb: function AS_Button_cb93c91aac534f59929a656e99438edb(eventobject) {
        var self = this;
        return self.createUUID.call(this);
    },
    /** onClick defined for CopyButton0daa4628bf14848 **/
    AS_Button_jd846989420d4d55a6c8bb34fa3fcd82: function AS_Button_jd846989420d4d55a6c8bb34fa3fcd82(eventobject) {
        var self = this;
        return self.deviceInfo.call(this);
    },
    /** onClick defined for CopyButton0c63014b7ec7743 **/
    AS_Button_dda85bea712e429c9cb96ddb7d1be97c: function AS_Button_dda85bea712e429c9cb96ddb7d1be97c(eventobject) {
        var self = this;
        return self.freeMemory.call(this);
    },
    /** onClick defined for CopyButton0a9d77708c9c548 **/
    AS_Button_e8949534feea49cc8fe3a488ff7b48af: function AS_Button_e8949534feea49cc8fe3a488ff7b48af(eventobject) {
        var self = this;
        return self.getDeviceId.call(this);
    },
    /** onClick defined for CopyButton0i0fe241cc1bf4c **/
    AS_Button_c33e361554274bba892e48ab3a7d866e: function AS_Button_c33e361554274bba892e48ab3a7d866e(eventobject) {
        var self = this;
        return self.getDeviceOrientation.call(this);
    },
    /** onClick defined for CopyButton0fdb632d83a854f **/
    AS_Button_ad4acab61bbe4e90a0e369051c7e293c: function AS_Button_ad4acab61bbe4e90a0e369051c7e293c(eventobject) {
        var self = this;
        return self.accelerometerSupport.call(this);
    },
    /** onClick defined for CopyButton0h06b6ab555414e **/
    AS_Button_f7ed69855b534f7f83fd4dc9b51789ca: function AS_Button_f7ed69855b534f7f83fd4dc9b51789ca(eventobject) {
        var self = this;
        return self.cameraSupport.call(this);
    },
    /** onClick defined for CopyButton0df3f69aaf58741 **/
    AS_Button_b27715e65df94a52b3d406f2f8a963a4: function AS_Button_b27715e65df94a52b3d406f2f8a963a4(eventobject) {
        var self = this;
        return self.gpsSupport.call(this);
    },
    /** onClick defined for CopyButton0fe9aa53c276b4e **/
    AS_Button_dabb403e469f49f0bca48fa6ff8c48e2: function AS_Button_dabb403e469f49f0bca48fa6ff8c48e2(eventobject) {
        var self = this;
        return self.orientationSupport.call(this);
    },
    /** onClick defined for CopyButton0ce7c086fea7a4a **/
    AS_Button_i62956de3829427a84775f9109255782: function AS_Button_i62956de3829427a84775f9109255782(eventobject) {
        var self = this;
        return self.hasTouchSupport.call(this);
    },
    /** onClick defined for CopyButton0cf52eb625db440 **/
    AS_Button_a439d9b11bf64203850860ecd3d78a54: function AS_Button_a439d9b11bf64203850860ecd3d78a54(eventobject) {
        var self = this;
        return self.userAgent.call(this);
    },
    /** onClick defined for CopyButton0e087acae185648 **/
    AS_Button_c72548320f3743abaab02797cf1f078e: function AS_Button_c72548320f3743abaab02797cf1f078e(eventobject) {
        var self = this;
        return self.toCurrency.call(this);
    },
    /** onClick defined for CopyButton0cc6d33d50aa646 **/
    AS_Button_c3506d1be9a7457d8707e99bff748809: function AS_Button_c3506d1be9a7457d8707e99bff748809(eventobject) {
        var self = this;
        return self.toNumber.call(this);
    }
});