define({ 

//To request the user for his rating on your app use the below API 
  requestAppReview: function()
  {
    kony.application.requestReview();
  }

 });