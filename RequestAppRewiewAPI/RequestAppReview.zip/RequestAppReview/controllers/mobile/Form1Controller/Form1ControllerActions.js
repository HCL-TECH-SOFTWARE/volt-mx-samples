define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnRequest **/
    AS_Button_efc1db0cdde549c78b31071eaf8b1b38: function AS_Button_efc1db0cdde549c78b31071eaf8b1b38(eventobject) {
        var self = this;
        return self.requestAppReview.call(this);
    }
});