define({ 

/*Use the below function to obtain the list of themes used in the Visualizer
  project*/
  getAllThemes: function()
  {
    var number = kony.theme.getAllThemes();
    alert("The list of themes associated with the app are "+ number);
  },
/*Use the below function to get the name of the current theme associated with the app
  the app*/
  getCurrentTheme: function()
  {
    var crntTheme = kony.theme.getCurrentTheme();
    alert("current theme is:" + crntTheme);
  },
/*Use the below function to check if the theme mentioned is present in 
the app or not*/
  isThemePresent: function()
  {
    if(kony.theme.isThemePresent("Dark")===true)
    {
      alert("Dark theme is supported by this application");
    }
    else{
      alert("Dark theme is not supported by this application");
    }
  },
/*Use the below function to set a theme to your app during runtime. Here
we configured a  listbox widget, that changes the theme based on your 
selection.*/ 
  setCurrentTheme: function()
  {
    if(this.view.lstbox.selectedKey=="lb1")
    {
      kony.theme.setCurrentTheme("Light", this.onsuccess, this.onerror);
      this.view.forceLayout();
    }
    else if(this.view.lstbox.selectedKey=="lb2")
    {
      kony.theme.setCurrentTheme("Dark", this.onsuccess, this.onerror);
      this.view.forceLayout();
    }
  },

  onsuccess: function()
  {
    if(kony.theme.getCurrentTheme()=="Light")
    {
      alert("You have set Light Theme");
    }
    else if(kony.theme.getCurrentTheme()=="Dark")
    {
      alert("You have set Dark theme");
    }
  },

  onerror: function()
  {
    alert("Could not set the skin");
  },

});