define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnGetAll **/
    AS_Button_a0d3e42a79c649b4b5d1ef5c4ae9946a: function AS_Button_a0d3e42a79c649b4b5d1ef5c4ae9946a(eventobject) {
        var self = this;
        return self.getAllThemes.call(this);
    },
    /** onClick defined for btnGetCurrent **/
    AS_Button_f6b38962df514ee689b76a6c38eebb40: function AS_Button_f6b38962df514ee689b76a6c38eebb40(eventobject) {
        var self = this;
        return self.getCurrentTheme.call(this);
    },
    /** onClick defined for btnIsTheme **/
    AS_Button_f48239a3fb4349ab9a536e0b94baa258: function AS_Button_f48239a3fb4349ab9a536e0b94baa258(eventobject) {
        var self = this;
        return self.isThemePresent.call(this);
    },
    /** onSelection defined for lstbox **/
    AS_ListBox_jf1a4b62f50d47aca1e9779c09ea90c9: function AS_ListBox_jf1a4b62f50d47aca1e9779c09ea90c9(eventobject) {
        var self = this;
        return self.setCurrentTheme.call(this);
    }
});