define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** postShow defined for Form2 **/
    AS_Form_f28fcd02507b4af49e7a60771026d5ab: function AS_Form_f28fcd02507b4af49e7a60771026d5ab(eventobject) {
        var self = this;
        kony.application.destroyForm("Form1");
        var ntf = new kony.mvc.Navigation("frmHome");
        ntf.navigate();
    }
});