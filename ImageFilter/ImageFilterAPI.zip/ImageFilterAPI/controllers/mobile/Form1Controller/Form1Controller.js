define({ 
imageBytes: "",
//By assigning the below function to the range slider widget, you can now drag the range slider to adjust the image brightness.
//#ifdef android  
  createFilterForAndroid: function()
{
  this.view.btniOS.isVisible=false;
  this.view.sliderBright.isVisible=true;
  var imgBright =  kony.image.createImage(this.imageBytes);
  var filterobj =  kony.filter.createFilter();
  var percentagevalue= this.view.sliderBright.selectedValue;
  var scalevalue = parseFloat(percentagevalue/10);
  var filterData = {
    "filterName": kony.filter.BRIGHTNESS ,
    "inputImage": imgBright,
    "inputBrightness": scalevalue
  };
  filterobj.applyFilter(filterData);
  var imageObj = filterobj.getOutputImage();
  this.view.imgBrite.rawBytes = imageObj.getImageAsRawBytes();
  this.view.forceLayout();
  },
//#endif  
  
//#ifdef iphone 
//By using the below function, you can add a cartoon filter over your image.
  createFilterForiOS: function(){
 
  var imgBright =  kony.image.createImage(this.imageBytes);
  var filterobj =  kony.filter.createFilter();
  var filterData = {
    "filterName": kony.filter.COMIC_EFFECT,
    "inputImage": imgBright,
  };
  filterobj.applyFilter(filterData);
  var imageObj = filterobj.getOutputImage();
  this.view.imgBrite.rawBytes = imageObj.getImageAsRawBytes();
  this.view.forceLayout();
  }
//#endif


 });
