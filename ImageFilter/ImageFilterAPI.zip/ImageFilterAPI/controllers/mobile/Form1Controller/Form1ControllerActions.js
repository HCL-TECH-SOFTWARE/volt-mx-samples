define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onSlide defined for sliderBright **/
    AS_Slider_a06fdaad277c499f9b219c4cc1c83b3e: function AS_Slider_a06fdaad277c499f9b219c4cc1c83b3e(eventobject, selectedvalue) {
        var self = this;
        return self.createFilterForAndroid.call(this);
    },
    /** onClick defined for btniOS **/
    AS_Button_ga8362c4c5844344b11f64001db54601: function AS_Button_ga8362c4c5844344b11f64001db54601(eventobject) {
        var self = this;
        return self.createFilterForiOS.call(this);
    },
    /** onCapture defined for camera1 **/
    AS_Camera_c3d5abb65a244dbdb52899c946afd5cf: function AS_Camera_c3d5abb65a244dbdb52899c946afd5cf(eventobject) {
        var self = this;
        var imageRawBytes = this.view.camera1.rawBytes;
        this.view.imgBrite.rawBytes = imageRawBytes;
        this.imageBytes = imageRawBytes;
    },
    /** preShow defined for Form1 **/
    AS_Form_h019b4aeed2f491a935a60bb112b605a: function AS_Form_h019b4aeed2f491a935a60bb112b605a(eventobject) {
        var self = this;
        //#ifdef android
        this.view.btniOS.isVisible = false;
        this.view.sliderBright.isVisible = true;
        //#endif
        //#ifdef iphone
        this.view.sliderBright.isVisible = false;
        this.view.btniOS.isVisible = true;
        //#endif
    }
});