define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnCreateTask **/
    AS_Button_a3727f8f683c44d79209ed1aadbd1294: function AS_Button_a3727f8f683c44d79209ed1aadbd1294(eventobject) {
        var self = this;
        return self.onClick_Button.call(this);
    },
    /** preShow defined for frmHome1 **/
    AS_Form_f96ba2b8352b485c82b2a45516255a0e: function AS_Form_f96ba2b8352b485c82b2a45516255a0e(eventobject) {
        var self = this;
        return self.postshow.call(this);
    }
});