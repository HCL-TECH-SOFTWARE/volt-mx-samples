function AS_FlexContainer_cb6758d534e44c40a65c9b6199b2fbf4(eventobject) {
    var self = this;
    return self.setDefaultDataToSegment.call(this);
}