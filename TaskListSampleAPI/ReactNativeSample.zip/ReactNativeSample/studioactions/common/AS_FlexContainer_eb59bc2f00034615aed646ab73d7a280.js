function AS_FlexContainer_eb59bc2f00034615aed646ab73d7a280(eventobject) {
    var self = this;
    return self.getFormContext.call(this, null);
}