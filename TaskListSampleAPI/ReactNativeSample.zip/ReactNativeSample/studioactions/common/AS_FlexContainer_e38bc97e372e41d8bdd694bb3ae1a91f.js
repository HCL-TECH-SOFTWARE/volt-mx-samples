function AS_FlexContainer_e38bc97e372e41d8bdd694bb3ae1a91f(eventobject) {
    var self = this;
    this.view.segTasks.removeAll();
}