define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preShow defined for TaskList **/
    AS_FlexContainer_eb59bc2f00034615aed646ab73d7a280: function AS_FlexContainer_eb59bc2f00034615aed646ab73d7a280(eventobject) {
        var self = this;
        return self.getFormContext.call(this, null);
    },
    /** postShow defined for TaskList **/
    AS_FlexContainer_cb6758d534e44c40a65c9b6199b2fbf4: function AS_FlexContainer_cb6758d534e44c40a65c9b6199b2fbf4(eventobject) {
        var self = this;
        return self.setDefaultDataToSegment.call(this);
    }
});